"""
Screenshot capture script for PathFinder Lab.
"""

import sys
import os
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer
from ui.main_window import MainWindow

app = None
window = None

def capture():
    global app, window
    try:
        pixmap = window.grab()
        out_path = r"C:\Users\praja\.gemini\antigravity-ide\brain\7546c457-4f3d-4440-89a9-ade65e6ea7eb\pathfinder_app_screenshot.png"
        pixmap.save(out_path, "PNG")
        print(f"SAVED: {out_path}", flush=True)
    except Exception as e:
        print(f"ERROR: {e}", flush=True)
    finally:
        app.quit()

def main():
    global app, window
    app = QApplication(sys.argv)
    window = MainWindow()
    window.resize(1536, 1024)
    window.show()
    # After initial demo loads (100ms) and renders, capture screenshot
    QTimer.singleShot(800, capture)
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
