"""
Compact mini-graph canvas embedded inside algorithm cards.
Renders node layout, algorithm-specific explored edges in accent colors,
and golden amber shortest path.
"""

from typing import List, Tuple, Optional, Dict
from PySide6.QtWidgets import QWidget
from PySide6.QtCore import Qt, QRectF, QPointF
from PySide6.QtGui import QPainter, QPen, QBrush, QColor, QFont
from graph.graph_data import GraphData
from ui.theme import (
    ACCENT_PATH,
    NODE_SOURCE_BORDER, NODE_SOURCE_FILL,
    NODE_TARGET_BORDER, NODE_TARGET_FILL,
    NODE_NORMAL_BORDER, NODE_NORMAL_FILL
)


class MiniGraphWidget(QWidget):
    """Compact lightweight widget for rendering mini graph previews in algorithm cards."""

    def __init__(self, accent_color: str, parent=None):
        super().__init__(parent)
        self.accent_color = accent_color
        self.graph: Optional[GraphData] = None
        self.source_node: Optional[int] = None
        self.target_node: Optional[int] = None
        self.shortest_path: List[int] = []
        self.explored_edges: List[Tuple[int, int]] = []
        self.setFixedHeight(85)
        self.setMinimumWidth(200)

    def set_data(
        self,
        graph: GraphData,
        source: Optional[int],
        target: Optional[int],
        shortest_path: Optional[List[int]],
        explored_edges: Optional[List[Tuple[int, int]]]
    ):
        self.graph = graph
        self.source_node = source
        self.target_node = target
        self.shortest_path = shortest_path or []
        self.explored_edges = explored_edges or []
        self.update()

    def paintEvent(self, event):
        if not self.graph or not self.graph.nodes:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)

        # Scale coordinates to fit inside widget with padding
        padding = 18.0
        w = float(self.width())
        h = float(self.height())

        xs = [pos[0] for pos in self.graph.positions.values()] if self.graph.positions else [100.0]
        ys = [pos[1] for pos in self.graph.positions.values()] if self.graph.positions else [100.0]

        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)

        span_x = (max_x - min_x) if (max_x - min_x) > 1e-4 else 1.0
        span_y = (max_y - min_y) if (max_y - min_y) > 1e-4 else 1.0

        def to_screen(gx: float, gy: float) -> QPointF:
            sx = padding + ((gx - min_x) / span_x) * (w - 2 * padding)
            sy = padding + ((gy - min_y) / span_y) * (h - 2 * padding)
            return QPointF(sx, sy)

        # Precompute path and explored sets
        path_edges = set()
        if len(self.shortest_path) >= 2:
            for i in range(len(self.shortest_path) - 1):
                u = self.shortest_path[i]
                v = self.shortest_path[i + 1]
                path_edges.add((min(u, v), max(u, v)))

        explored_set = set()
        for u, v in self.explored_edges:
            explored_set.add((min(u, v), max(u, v)))

        # 1. Draw Normal Edges
        pen_normal = QPen(QColor("#E2E8F0"), 1.2)
        painter.setPen(pen_normal)
        for u, v, _ in self.graph.edges:
            pair = (min(u, v), max(u, v))
            if pair not in path_edges and pair not in explored_set:
                p1 = to_screen(*self.graph.positions.get(u, (0, 0)))
                p2 = to_screen(*self.graph.positions.get(v, (0, 0)))
                painter.drawLine(p1, p2)

        # 2. Draw Explored Edges (dashed accent color)
        pen_explored = QPen(QColor(self.accent_color), 1.6, Qt.PenStyle.DashLine)
        painter.setPen(pen_explored)
        for u, v, _ in self.graph.edges:
            pair = (min(u, v), max(u, v))
            if pair in explored_set and pair not in path_edges:
                p1 = to_screen(*self.graph.positions.get(u, (0, 0)))
                p2 = to_screen(*self.graph.positions.get(v, (0, 0)))
                painter.drawLine(p1, p2)

        # 3. Draw Shortest Path Edges (golden amber)
        pen_path = QPen(QColor(ACCENT_PATH), 3.0)
        pen_path.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen_path)
        for u, v, _ in self.graph.edges:
            pair = (min(u, v), max(u, v))
            if pair in path_edges:
                p1 = to_screen(*self.graph.positions.get(u, (0, 0)))
                p2 = to_screen(*self.graph.positions.get(v, (0, 0)))
                painter.drawLine(p1, p2)

        # 4. Draw Nodes
        node_radius = 8.5
        font = QFont("Segoe UI", 7, QFont.Weight.Bold)
        painter.setFont(font)

        for node in self.graph.nodes:
            pos = to_screen(*self.graph.positions.get(node, (0, 0)))

            if node == self.source_node:
                p_border = QColor(NODE_SOURCE_BORDER)
                p_fill = QColor(NODE_SOURCE_FILL)
                p_text = QColor("#065F46")
            elif node == self.target_node:
                p_border = QColor(NODE_TARGET_BORDER)
                p_fill = QColor(NODE_TARGET_FILL)
                p_text = QColor("#991B1B")
            elif node in self.shortest_path:
                p_border = QColor(ACCENT_PATH)
                p_fill = QColor("#FEF3C7")
                p_text = QColor("#92400E")
            else:
                p_border = QColor(NODE_NORMAL_BORDER)
                p_fill = QColor(NODE_NORMAL_FILL)
                p_text = QColor("#10234D")

            painter.setPen(QPen(p_border, 1.8))
            painter.setBrush(QBrush(p_fill))
            painter.drawEllipse(pos, node_radius, node_radius)

            painter.setPen(QPen(p_text))
            painter.drawText(
                QRectF(pos.x() - node_radius, pos.y() - node_radius, 2 * node_radius, 2 * node_radius),
                Qt.AlignmentFlag.AlignCenter,
                str(node)
            )

        painter.end()
