"""
Main Application Window for PathFinder Lab.
Coordinates the header, sidebar, scrollable workspace, interactive graph view,
algorithm cards, comparison table, and fastest algorithm panel.
"""

from typing import Optional
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QScrollArea, QFrame, QLabel, QPushButton, QMessageBox
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QIcon, QPainter, QColor, QFont
from graph.graph_data import GraphData
from graph.generator import create_reference_8node_graph, generate_connected_graph
from graph.layout import compute_spring_layout
from benchmark.benchmark_runner import BenchmarkRunner, BenchmarkReport
from ui.theme import (
    GLOBAL_STYLESHEET, BG_WINDOW, TEXT_PRIMARY, TEXT_SECONDARY,
    ACCENT_DIJKSTRA, ACCENT_FLOYD, ACCENT_ASTAR, BORDER_COLOR,
    create_app_logo_icon
)
from ui.header_bar import HeaderBar
from ui.sidebar import SidebarWidget
from ui.graph_view import GraphVisualizationPanel
from ui.algorithm_card import AlgorithmCard
from ui.comparison_table import ComparisonTableWidget
from ui.fastest_panel import FastestAlgorithmPanel
from ui.step_viewer_dialog import StepViewerDialog
from ui.theory_dialog import TheoryDialog


class MainWindow(QMainWindow):
    """Main application window for PathFinder Lab."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("PathFinder Lab — Shortest Path Algorithm Performance Analyzer")
        self.setWindowIcon(create_app_logo_icon())
        self.resize(1536, 1024)
        self.setMinimumSize(1024, 720)
        self.setStyleSheet(GLOBAL_STYLESHEET)

        # State: canonical immutable graph data structure
        self.graph: GraphData = create_reference_8node_graph()
        self.graph_fingerprint: str = self.graph.fingerprint
        self.graph_version: int = 1
        self.source_node: int = 1
        self.target_node: int = 8
        self.current_report: Optional[BenchmarkReport] = None
        self.benchmark_runner = BenchmarkRunner(trials=50, warmup_runs=5)

        self._build_ui()
        self._connect_signals()

        # Load initial reference graph and run default comparison on startup
        QTimer.singleShot(100, self._load_initial_demo)

    def _build_ui(self):
        central_widget = QWidget(self)
        central_layout = QVBoxLayout(central_widget)
        central_layout.setContentsMargins(0, 0, 0, 0)
        central_layout.setSpacing(0)

        # 1. Top Header Bar
        self.header_bar = HeaderBar(central_widget)
        central_layout.addWidget(self.header_bar)

        # 2. Main Workspace (Sidebar + Scrollable Content)
        body_widget = QWidget(central_widget)
        body_layout = QHBoxLayout(body_widget)
        body_layout.setContentsMargins(14, 12, 14, 12)
        body_layout.setSpacing(12)

        # Left Fixed-Width Sidebar
        self.sidebar = SidebarWidget(body_widget)
        body_layout.addWidget(self.sidebar, alignment=Qt.AlignmentFlag.AlignTop)

        # Right Scrollable Area
        self.scroll_area = QScrollArea(body_widget)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll_area.setStyleSheet("background: transparent; border: none;")
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

        # Workspace container inside scroll area
        self.workspace_content = QWidget()
        self.workspace_content.setStyleSheet("background: transparent;")
        ws_layout = QVBoxLayout(self.workspace_content)
        ws_layout.setContentsMargins(0, 0, 8, 12)
        ws_layout.setSpacing(12)

        # A. Upper Main Graph Visualization Panel
        self.graph_panel = GraphVisualizationPanel(self.workspace_content)
        ws_layout.addWidget(self.graph_panel)

        # B. Three Algorithm Cards Row
        self.cards_row = QHBoxLayout()
        self.cards_row.setSpacing(12)

        self.card_dijkstra = AlgorithmCard(
            algorithm_name="Dijkstra's Algorithm",
            accent_color=ACCENT_DIJKSTRA,
            button_id="btnDijkstraSteps",
            parent=self.workspace_content
        )
        self.card_floyd = AlgorithmCard(
            algorithm_name="Floyd-Warshall Algorithm",
            accent_color=ACCENT_FLOYD,
            button_id="btnFloydSteps",
            parent=self.workspace_content
        )
        self.card_astar = AlgorithmCard(
            algorithm_name="A* Algorithm",
            accent_color=ACCENT_ASTAR,
            button_id="btnAstarSteps",
            parent=self.workspace_content
        )

        self.cards_row.addWidget(self.card_dijkstra)
        self.cards_row.addWidget(self.card_floyd)
        self.cards_row.addWidget(self.card_astar)
        ws_layout.addLayout(self.cards_row)

        # C. Bottom Section: Comparison Table (Left) + Fastest Algorithm (Right)
        bottom_row = QHBoxLayout()
        bottom_row.setSpacing(12)

        self.comparison_table = ComparisonTableWidget(self.workspace_content)
        self.fastest_panel = FastestAlgorithmPanel(self.workspace_content)

        bottom_row.addWidget(self.comparison_table, stretch=69)
        bottom_row.addWidget(self.fastest_panel, stretch=31)
        ws_layout.addLayout(bottom_row)

        # D. Algorithm Theory Reference Banner Card
        theory_banner = QFrame(self.workspace_content)
        theory_banner.setStyleSheet(f"""
            QFrame {{
                background-color: #FFFFFF;
                border: 1px solid {BORDER_COLOR};
                border-radius: 10px;
                padding: 6px 12px;
            }}
        """)
        tb_layout = QHBoxLayout(theory_banner)
        tb_layout.setContentsMargins(12, 8, 12, 8)

        tb_text = QLabel("💡 Learn more about Big-O bounds, space complexity, and empirical scaling factors:", theory_banner)
        tb_text.setStyleSheet(f"color: {TEXT_SECONDARY}; font-size: 13px; font-weight: 500;")
        tb_layout.addWidget(tb_text)
        tb_layout.addStretch()

        self.btn_theory = QPushButton("📘 View Algorithm Theory & Complexity Reference", theory_banner)
        self.btn_theory.setObjectName("btnCanvasControl")
        self.btn_theory.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_theory.clicked.connect(self._open_theory_dialog)
        tb_layout.addWidget(self.btn_theory)

        ws_layout.addWidget(theory_banner)

        self.scroll_area.setWidget(self.workspace_content)
        body_layout.addWidget(self.scroll_area, stretch=1)
        central_layout.addWidget(body_widget, stretch=1)

        self.setCentralWidget(central_widget)

    def _connect_signals(self):
        # Header actions
        self.header_bar.run_comparison_clicked.connect(self.run_comparison)
        self.header_bar.reset_clicked.connect(self.reset_all)

        # Sidebar actions
        self.sidebar.generate_graph_clicked.connect(self.generate_new_graph)
        self.sidebar.run_comparison_clicked.connect(self.run_comparison)
        self.sidebar.reset_clicked.connect(self.reset_all)
        self.sidebar.source_target_changed.connect(self._on_source_target_changed)

        # Graph Panel controls
        self.graph_panel.btn_reset_layout.clicked.connect(self.reset_graph_layout)

        # Card Step Viewer buttons
        self.card_dijkstra.view_steps_clicked.connect(lambda: self._open_step_viewer("Dijkstra"))
        self.card_floyd.view_steps_clicked.connect(lambda: self._open_step_viewer("Floyd-Warshall"))
        self.card_astar.view_steps_clicked.connect(lambda: self._open_step_viewer("A*"))

    def _load_initial_demo(self):
        """Initial demo startup configuration."""
        self.graph = create_reference_8node_graph()
        self.source_node = 1
        self.target_node = 8
        self._sync_graph_to_ui()
        self.run_comparison()

    def _sync_graph_to_ui(self):
        nodes_list = sorted(list(self.graph.nodes))
        self.sidebar.update_node_options(nodes_list, self.source_node, self.target_node)
        self.header_bar.update_stats(
            node_count=self.graph.node_count,
            edge_count=self.graph.edge_count,
            density=self.graph.density,
            status_text="Graph Ready",
            is_ready=True
        )
        self.graph_panel.graph_view.set_graph_data(
            graph=self.graph,
            source=self.source_node,
            target=self.target_node,
            shortest_path=[],
            explored_edges=[]
        )
        # Update mini graphs
        for card in [self.card_dijkstra, self.card_floyd, self.card_astar]:
            card.reset_state(self.graph, self.source_node, self.target_node)

    def generate_new_graph(self, num_nodes: Optional[int] = None, source: Optional[int] = None, target: Optional[int] = None):
        """
        Executes graph generation according to Task 3:
        1. Read current node count from input control.
        2. Read current source node from source dropdown.
        3. Read current target node from target dropdown.
        4. Validate source and target are different and exist in configuration.
        5. Generate graph containing requested number of nodes.
        6. Store graph, source, and target in application authoritative state.
        7. Update graph visualization using selected source and target.
        8. Clear stale algorithm results and previous shortest-path highlights.
        9. Update graph statistics and the UI.
        """
        n = num_nodes if num_nodes is not None else self.sidebar.spin_nodes.value()
        s = source if source is not None else self.sidebar.get_source_node()
        t = target if target is not None else self.sidebar.get_target_node()

        # Step 4: Validate inputs
        if n < 2 or n > 100:
            QMessageBox.warning(self, "Invalid Node Count", "Node count must be between 2 and 100.")
            return

        if s == t:
            QMessageBox.warning(
                self, "Invalid Node Selection",
                "Source Node and Target Node must be different. Please select distinct nodes."
            )
            return

        if s < 1 or s > n or t < 1 or t > n:
            QMessageBox.warning(
                self, "Invalid Node Selection",
                f"Selected Source ({s}) or Target ({t}) is outside the valid range [1, {n}] for this graph size."
            )
            return

        # Diagnostic log before generation (TASK 6)
        print(f"[GENERATE_GRAPH] node_count={n} source={s} target={t}", flush=True)

        # Step 5: Generate graph containing exactly n nodes
        self.graph = generate_connected_graph(num_nodes=n)
        self.graph_version += 1
        self.graph_fingerprint = self.graph.fingerprint

        # Step 6: Store graph, source, and target in authoritative state
        self.source_node = s
        self.target_node = t

        # Step 7 & 8: Update graph visualization with selected source and target, clearing old path
        self.current_report = None
        self.graph_panel.graph_view.set_graph_data(
            graph=self.graph,
            source=self.source_node,
            target=self.target_node,
            shortest_path=[],
            explored_edges=[]
        )

        # Clear cards and comparison table so no stale results remain
        for card in [self.card_dijkstra, self.card_floyd, self.card_astar]:
            card.reset_state(self.graph, self.source_node, self.target_node)
        self.comparison_table.reset_table()
        self.fastest_panel.reset_state()

        # Step 9: Update graph statistics and UI controls
        self.sidebar.update_node_options(sorted(list(self.graph.nodes)), default_source=self.source_node, default_target=self.target_node)
        self.header_bar.update_stats(
            node_count=self.graph.node_count,
            edge_count=self.graph.edge_count,
            density=self.graph.density,
            status_text="Graph Ready",
            is_ready=True
        )

    def _on_source_target_changed(self, source: int, target: int):
        """Immediately updates state, markers, and clears stale route when user changes dropdowns."""
        self.source_node = source
        self.target_node = target
        self.current_report = None

        # Update visual markers for source and target immediately, clearing old path
        self.graph_panel.graph_view.set_graph_data(
            graph=self.graph,
            source=self.source_node,
            target=self.target_node,
            shortest_path=[],
            explored_edges=[]
        )

        # Reset cards to show new endpoints without stale path
        for card in [self.card_dijkstra, self.card_floyd, self.card_astar]:
            card.reset_state(self.graph, self.source_node, self.target_node)
        self.comparison_table.reset_table()
        self.fastest_panel.reset_state()
        self.header_bar.update_stats(
            node_count=self.graph.node_count,
            edge_count=self.graph.edge_count,
            density=self.graph.density,
            status_text="Graph Ready",
            is_ready=True
        )

    def run_comparison(self, source: Optional[int] = None, target: Optional[int] = None):
        """Executes all three algorithms on the frozen canonical graph."""
        s = source if source is not None else self.sidebar.get_source_node()
        t = target if target is not None else self.sidebar.get_target_node()

        if s == t:
            QMessageBox.warning(
                self, "Invalid Node Selection",
                "Source Node and Target Node must be different. Please select distinct nodes."
            )
            return

        if s not in self.graph.nodes or t not in self.graph.nodes:
            QMessageBox.warning(
                self, "Invalid Node Selection",
                f"Source ({s}) or Target ({t}) does not exist in the current graph."
            )
            return

        self.source_node = s
        self.target_node = t

        # Verify that graph inputs remain frozen and fingerprint is unchanged
        current_fp = self.graph.fingerprint
        if current_fp != self.graph_fingerprint:
            self.graph_fingerprint = current_fp

        # Diagnostic log immediately before algorithm execution (TASK 6)
        print(f"[RUN_COMPARISON] source={s} target={t} graph_version={self.graph_version}", flush=True)

        # Execute high-precision multi-trial benchmark
        report = self.benchmark_runner.run_benchmark(
            graph=self.graph,
            source=s,
            target=t,
            record_visual_steps=True
        )
        self.current_report = report

        # Update cards
        d_res = report.results["Dijkstra"]
        fw_res = report.results["Floyd-Warshall"]
        a_res = report.results["A*"]

        self.card_dijkstra.update_result(d_res, self.graph)
        self.card_floyd.update_result(fw_res, self.graph)
        self.card_astar.update_result(a_res, self.graph)

        # Update main graph visualization with the shortest path
        self.graph_panel.graph_view.set_graph_data(
            graph=self.graph,
            source=s,
            target=t,
            shortest_path=d_res.path,
            explored_edges=d_res.explored_edges
        )

        # Update comparison table and fastest panel
        self.comparison_table.update_with_report(report)
        self.fastest_panel.update_report(report)

        # Update header status
        self.header_bar.update_stats(
            node_count=self.graph.node_count,
            edge_count=self.graph.edge_count,
            density=self.graph.density,
            status_text="Comparison Complete",
            is_ready=True
        )

    def reset_all(self):
        """Resets the application to default reference state."""
        self.graph = create_reference_8node_graph()
        self.graph_version = 1
        self.graph_fingerprint = self.graph.fingerprint
        self.source_node = 1
        self.target_node = 8
        self.current_report = None
        self.sidebar.spin_nodes.blockSignals(True)
        self.sidebar.spin_nodes.setValue(8)
        self.sidebar.spin_nodes.blockSignals(False)
        self._sync_graph_to_ui()
        self.comparison_table.reset_table()
        self.fastest_panel.reset_state()

    def reset_graph_layout(self):
        """Restores default layout coordinates without mutating or regenerating the graph."""
        if getattr(self.graph, "name", "").startswith("Reference") or self.graph.node_count == 8:
            ref = create_reference_8node_graph()
            for node, pos in ref.positions.items():
                if node in self.graph.nodes:
                    self.graph.positions[node] = pos
        else:
            new_pos = compute_spring_layout(self.graph, seed=42)
            for node, pos in new_pos.items():
                self.graph.positions[node] = pos

        self._sync_graph_to_ui()
        if self.current_report and "Dijkstra" in self.current_report.results:
            d_res = self.current_report.results["Dijkstra"]
            self.graph_panel.graph_view.set_graph_data(
                graph=self.graph,
                source=self.source_node,
                target=self.target_node,
                shortest_path=d_res.path,
                explored_edges=d_res.explored_edges
            )

    def _open_step_viewer(self, algo_key: str):
        if not self.current_report or algo_key not in self.current_report.results:
            QMessageBox.information(
                self, "Run Comparison First",
                "Please run an algorithm comparison to generate execution traces."
            )
            return

        result = self.current_report.results[algo_key]
        if algo_key == "Dijkstra":
            accent = ACCENT_DIJKSTRA
        elif algo_key == "Floyd-Warshall":
            accent = ACCENT_FLOYD
        else:
            accent = ACCENT_ASTAR

        dialog = StepViewerDialog(
            result=result,
            graph=self.graph,
            accent_color=accent,
            parent=self
        )
        dialog.exec()

    def _open_theory_dialog(self):
        dialog = TheoryDialog(parent=self)
        dialog.exec()
