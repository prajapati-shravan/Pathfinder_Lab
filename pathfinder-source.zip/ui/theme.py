"""
Theme constants, color palettes, and global Qt Style Sheets (QSS) for PathFinder Lab.
Strict Light Theme with high visual polish matching the reference design.
"""

from PySide6.QtGui import QColor, QFont, QIcon, QPixmap, QPainter, QPen, QBrush
from PySide6.QtCore import Qt, QRectF, QPointF

# Color Palette Constants
BG_WINDOW = "#F5F8FC"
BG_PANEL = "#FFFFFF"
BORDER_COLOR = "#DCE5F0"
BORDER_HOVER = "#CBD5E1"
TEXT_PRIMARY = "#10234D"
TEXT_SECONDARY = "#64748B"
TEXT_MUTED = "#94A3B8"

# Algorithm Accents
ACCENT_DIJKSTRA = "#2563EB"   # Blue
ACCENT_FLOYD = "#7C3AED"      # Purple
ACCENT_ASTAR = "#059669"      # Emerald Green
ACCENT_PATH = "#F59E0B"       # Shortest path golden amber
ACCENT_PATH_LIGHT = "#FEF3C7" # Light golden amber

# Node Colors
NODE_SOURCE_FILL = "#ECFDF5"
NODE_SOURCE_BORDER = "#10B981"
NODE_TARGET_FILL = "#FEF2F2"
NODE_TARGET_BORDER = "#EF4444"
NODE_NORMAL_FILL = "#E0F2FE"
NODE_NORMAL_BORDER = "#38BDF8"
EDGE_NORMAL = "#CBD5E1"

# Status Badges
BG_SUCCESS = "#DEF7EC"
TEXT_SUCCESS = "#03543F"
BG_WARNING = "#FEF3C7"
TEXT_WARNING = "#92400E"
BG_ERROR = "#FEE2E2"
TEXT_ERROR = "#991B1B"
BG_BADGE = "#F1F5F9"
TEXT_BADGE = "#334155"


GLOBAL_STYLESHEET = f"""
/* Global Window and Base Widget */
QWidget {{
    background-color: transparent;
    color: {TEXT_PRIMARY};
    font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
    font-size: 13px;
}}

QLabel {{
    background-color: transparent;
    border: none;
}}

QMainWindow {{
    background-color: {BG_WINDOW};
}}

/* Main Panels and Cards */
.CardPanel {{
    background-color: {BG_PANEL};
    border: 1px solid {BORDER_COLOR};
    border-radius: 12px;
}}

.SidebarPanel {{
    background-color: {BG_PANEL};
    border: 1px solid {BORDER_COLOR};
    border-radius: 12px;
}}

.HeaderPanel {{
    background-color: {BG_PANEL};
    border-bottom: 1px solid {BORDER_COLOR};
}}

/* Scrollbars */
QScrollBar:vertical {{
    background: transparent;
    width: 8px;
    margin: 0px;
    border-radius: 4px;
}}

QScrollBar::handle:vertical {{
    background: #CBD5E1;
    min-height: 24px;
    border-radius: 4px;
}}

QScrollBar::handle:vertical:hover {{
    background: #94A3B8;
}}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0px;
}}

QScrollBar:horizontal {{
    background: transparent;
    height: 8px;
    margin: 0px;
    border-radius: 4px;
}}

QScrollBar::handle:horizontal {{
    background: #CBD5E1;
    min-width: 24px;
    border-radius: 4px;
}}

QScrollBar::handle:horizontal:hover {{
    background: #94A3B8;
}}

QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
    width: 0px;
}}

/* Buttons */
QPushButton {{
    font-weight: 600;
    border-radius: 8px;
    padding: 8px 16px;
    font-size: 13px;
}}

QPushButton#btnPrimaryBlue {{
    background-color: #2563EB;
    color: #FFFFFF;
    border: none;
}}

QPushButton#btnPrimaryBlue:hover {{
    background-color: #1D4ED8;
}}

QPushButton#btnPrimaryBlue:pressed {{
    background-color: #1E40AF;
}}

QPushButton#btnPrimaryGreen {{
    background-color: #10B981;
    color: #FFFFFF;
    border: none;
}}

QPushButton#btnPrimaryGreen:hover {{
    background-color: #059669;
}}

QPushButton#btnPrimaryGreen:pressed {{
    background-color: #047857;
}}

QPushButton#btnReset {{
    background-color: #FFFFFF;
    color: #EF4444;
    border: 1px solid #FCA5A5;
}}

QPushButton#btnReset:hover {{
    background-color: #FEF2F2;
    border-color: #EF4444;
}}

QPushButton#btnReset:pressed {{
    background-color: #FEE2E2;
}}

QPushButton#btnCanvasControl {{
    background-color: #FFFFFF;
    color: {TEXT_PRIMARY};
    border: 1px solid {BORDER_COLOR};
    border-radius: 6px;
    padding: 4px 10px;
    font-size: 12px;
    font-weight: 500;
}}

QPushButton#btnCanvasControl:hover {{
    background-color: #F8FAFC;
    border-color: {BORDER_HOVER};
}}

QPushButton#btnCanvasControl:pressed {{
    background-color: #F1F5F9;
}}

/* Outline Buttons on Algorithm Cards */
QPushButton#btnDijkstraSteps {{
    background-color: #FFFFFF;
    color: {ACCENT_DIJKSTRA};
    border: 1px solid #BFDBFE;
    border-radius: 6px;
    padding: 7px 12px;
    font-size: 12px;
}}

QPushButton#btnDijkstraSteps:hover {{
    background-color: #EFF6FF;
    border-color: {ACCENT_DIJKSTRA};
}}

QPushButton#btnFloydSteps {{
    background-color: #FFFFFF;
    color: {ACCENT_FLOYD};
    border: 1px solid #DDD6FE;
    border-radius: 6px;
    padding: 7px 12px;
    font-size: 12px;
}}

QPushButton#btnFloydSteps:hover {{
    background-color: #F5F3FF;
    border-color: {ACCENT_FLOYD};
}}

QPushButton#btnAstarSteps {{
    background-color: #FFFFFF;
    color: {ACCENT_ASTAR};
    border: 1px solid #A7F3D0;
    border-radius: 6px;
    padding: 7px 12px;
    font-size: 12px;
}}

QPushButton#btnAstarSteps:hover {{
    background-color: #ECFDF5;
    border-color: {ACCENT_ASTAR};
}}

/* Inputs */
QSpinBox, QComboBox {{
    background-color: #FFFFFF;
    border: 1px solid {BORDER_COLOR};
    border-radius: 8px;
    padding: 6px 10px;
    color: {TEXT_PRIMARY};
    font-size: 13px;
    font-weight: 500;
    min-height: 20px;
}}

QSpinBox:focus, QComboBox:focus {{
    border: 1px solid #3B82F6;
}}

QComboBox::drop-down {{
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 24px;
    border-left: none;
}}

QComboBox QAbstractItemView {{
    background-color: #FFFFFF;
    border: 1px solid {BORDER_COLOR};
    selection-background-color: #EFF6FF;
    selection-color: {TEXT_PRIMARY};
    border-radius: 6px;
    padding: 4px;
}}

/* Checkbox */
QCheckBox {{
    color: {TEXT_PRIMARY};
    font-size: 12px;
    font-weight: 500;
    spacing: 6px;
}}

QCheckBox::indicator {{
    width: 16px;
    height: 16px;
    border: 1px solid {BORDER_COLOR};
    border-radius: 4px;
    background-color: #FFFFFF;
}}

QCheckBox::indicator:checked {{
    background-color: #2563EB;
    border-color: #2563EB;
    image: none;
}}

/* Table Widget */
QTableWidget {{
    background-color: #FFFFFF;
    border: 1px solid {BORDER_COLOR};
    border-radius: 8px;
    gridline-color: #F1F5F9;
    font-size: 13px;
}}

QHeaderView::section {{
    background-color: #F8FAFC;
    color: {TEXT_SECONDARY};
    padding: 8px 10px;
    border: none;
    border-bottom: 1px solid {BORDER_COLOR};
    font-weight: 600;
    font-size: 12px;
}}

QTableWidget::item {{
    padding: 8px 10px;
    border-bottom: 1px solid #F1F5F9;
}}

QTableWidget::item:selected {{
    background-color: #EFF6FF;
    color: {TEXT_PRIMARY};
}}
"""


def create_app_logo_icon() -> QIcon:
    """Generates the connected-nodes app logo icon."""
    pix = QPixmap(64, 64)
    pix.fill(Qt.GlobalColor.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)

    # Draw lines
    pen = QPen(QColor("#2563EB"), 4)
    p.setPen(pen)
    p.drawLine(16, 20, 48, 16)
    p.drawLine(16, 20, 28, 48)
    p.drawLine(48, 16, 44, 46)
    p.drawLine(28, 48, 44, 46)

    # Draw nodes
    nodes = [(16, 20), (48, 16), (28, 48), (44, 46)]
    for x, y in nodes:
        p.setBrush(QBrush(QColor("#FFFFFF")))
        p.setPen(QPen(QColor("#2563EB"), 3))
        p.drawEllipse(QPointF(x, y), 8, 8)
        p.setBrush(QBrush(QColor("#2563EB")))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(QPointF(x, y), 4, 4)

    p.end()
    return QIcon(pix)


def create_trophy_icon() -> QIcon:
    """Generates a warm golden trophy icon for the fastest algorithm panel."""
    pix = QPixmap(32, 32)
    pix.fill(Qt.GlobalColor.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setBrush(QBrush(QColor("#F59E0B")))
    p.setPen(QPen(QColor("#D97706"), 1.5))
    
    # Cup
    p.drawRoundedRect(QRectF(8, 6, 16, 12), 3, 3)
    # Stem & base
    p.drawRect(QRectF(14, 18, 4, 6))
    p.drawRoundedRect(QRectF(9, 24, 14, 4), 2, 2)
    # Handles
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawArc(QRectF(4, 7, 8, 8), 90 * 16, 180 * 16)
    p.drawArc(QRectF(20, 7, 8, 8), 270 * 16, 180 * 16)

    p.end()
    return QIcon(pix)
