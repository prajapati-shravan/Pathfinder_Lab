"""
Top Header Bar widget displaying logo, titles, graph stat badges, and primary action buttons.
"""

from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QVBoxLayout, QLabel, QPushButton, QWidget
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QFont, QPixmap, QPainter, QPen, QBrush
from ui.theme import (
    TEXT_PRIMARY, TEXT_SECONDARY, BORDER_COLOR,
    create_app_logo_icon, BG_SUCCESS, TEXT_SUCCESS
)


class HeaderBar(QFrame):
    """Application top header bar."""

    run_comparison_clicked = Signal()
    reset_clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("TopHeaderBar")
        self.setStyleSheet(f"""
            QFrame#TopHeaderBar {{
                background-color: #FFFFFF;
                border-bottom: 1px solid {BORDER_COLOR};
                min-height: 54px;
                max-height: 58px;
            }}
        """)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(20, 10, 20, 10)
        layout.setSpacing(16)

        # 1. Left: Logo and Title / Subtitle
        left_layout = QHBoxLayout()
        left_layout.setSpacing(12)

        logo_lbl = QLabel(self)
        logo_lbl.setPixmap(create_app_logo_icon().pixmap(36, 36))
        left_layout.addWidget(logo_lbl)

        title_box = QVBoxLayout()
        title_box.setSpacing(2)

        app_title = QLabel("PathFinder Lab", self)
        app_title.setStyleSheet(f"font-size: 18px; font-weight: 800; color: {TEXT_PRIMARY};")

        app_subtitle = QLabel("Shortest Path Algorithm Performance Analyzer", self)
        app_subtitle.setStyleSheet(f"font-size: 11px; font-weight: 500; color: {TEXT_SECONDARY};")

        title_box.addWidget(app_title)
        title_box.addWidget(app_subtitle)
        left_layout.addLayout(title_box)

        layout.addLayout(left_layout)
        layout.addStretch(1)

        # 2. Center: Graph Stat Badges
        self.center_stats = QHBoxLayout()
        self.center_stats.setSpacing(8)

        self.badge_nodes = self._create_stat_badge("Nodes: 8")
        self.badge_edges = self._create_stat_badge("Edges: 12")
        self.badge_type = self._create_stat_badge("Graph Type: Undirected")
        self.badge_density = self._create_stat_badge("Density: 0.43")

        self.badge_status = QLabel("● Graph Ready", self)
        self.badge_status.setStyleSheet(f"""
            QLabel {{
                background-color: {BG_SUCCESS};
                color: {TEXT_SUCCESS};
                font-size: 11px;
                font-weight: 700;
                padding: 5px 12px;
                border-radius: 12px;
            }}
        """)

        self.center_stats.addWidget(self.badge_nodes)
        self.center_stats.addWidget(self.badge_edges)
        self.center_stats.addWidget(self.badge_type)
        self.center_stats.addWidget(self.badge_density)
        self.center_stats.addWidget(self.badge_status)

        layout.addLayout(self.center_stats)
        layout.addStretch(1)

        # 3. Right: Action Buttons
        right_layout = QHBoxLayout()
        right_layout.setSpacing(10)

        self.btn_run = QPushButton("▶ Run Comparison", self)
        self.btn_run.setObjectName("btnPrimaryBlue")
        self.btn_run.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_run.clicked.connect(self.run_comparison_clicked)

        self.btn_reset = QPushButton("↺ Reset", self)
        self.btn_reset.setObjectName("btnReset")
        self.btn_reset.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_reset.clicked.connect(self.reset_clicked)

        right_layout.addWidget(self.btn_run)
        right_layout.addWidget(self.btn_reset)

        layout.addLayout(right_layout)

    def _create_stat_badge(self, text: str) -> QLabel:
        lbl = QLabel(text, self)
        lbl.setStyleSheet(f"""
            QLabel {{
                background-color: #F8FAFC;
                color: {TEXT_PRIMARY};
                border: 1px solid {BORDER_COLOR};
                font-size: 11px;
                font-weight: 600;
                padding: 5px 10px;
                border-radius: 12px;
            }}
        """)
        return lbl

    def update_stats(self, node_count: int, edge_count: int, density: float, status_text: str = "Graph Ready", is_ready: bool = True):
        self.badge_nodes.setText(f"Nodes: {node_count}")
        self.badge_edges.setText(f"Edges: {edge_count}")
        self.badge_density.setText(f"Density: {density:.2f}")

        if is_ready:
            self.badge_status.setText(f"● {status_text}")
            self.badge_status.setStyleSheet(f"""
                QLabel {{
                    background-color: {BG_SUCCESS};
                    color: {TEXT_SUCCESS};
                    font-size: 11px;
                    font-weight: 700;
                    padding: 5px 12px;
                    border-radius: 12px;
                }}
            """)
        else:
            self.badge_status.setText(f"● {status_text}")
            self.badge_status.setStyleSheet("""
                QLabel {
                    background-color: #FEF3C7;
                    color: #92400E;
                    font-size: 11px;
                    font-weight: 700;
                    padding: 5px 12px;
                    border-radius: 12px;
                }
            """)
