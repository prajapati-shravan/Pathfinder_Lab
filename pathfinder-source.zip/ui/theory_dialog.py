"""
Algorithm Theory and Complexity modal dialog providing formal educational explanations.
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QTextBrowser, QFrame
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont
from ui.theme import (
    TEXT_PRIMARY, TEXT_SECONDARY, BORDER_COLOR,
    ACCENT_DIJKSTRA, ACCENT_FLOYD, ACCENT_ASTAR, BG_WINDOW
)


class TheoryDialog(QDialog):
    """Educational dialogue detailing theoretical complexity vs empirical performance."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Algorithm Theory & Complexity Reference — PathFinder Lab")
        self.resize(800, 600)
        self.setStyleSheet(f"""
            QDialog {{
                background-color: {BG_WINDOW};
            }}
            QFrame.SectionCard {{
                background-color: #FFFFFF;
                border: 1px solid {BORDER_COLOR};
                border-radius: 10px;
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(14)

        # Header
        header = QHBoxLayout()
        title = QLabel("Algorithm Theory & Theoretical Complexity", self)
        title.setStyleSheet(f"font-size: 18px; font-weight: 800; color: {TEXT_PRIMARY};")
        header.addWidget(title)
        header.addStretch()

        btn_close = QPushButton("Close", self)
        btn_close.setObjectName("btnCanvasControl")
        btn_close.clicked.connect(self.accept)
        header.addWidget(btn_close)
        layout.addLayout(header)

        # Comparison Table Card
        table_frame = QFrame(self)
        table_frame.setProperty("class", "SectionCard")
        t_layout = QVBoxLayout(table_frame)
        t_layout.setContentsMargins(14, 14, 14, 14)

        t_lbl = QLabel("Theoretical Complexity Overview", table_frame)
        t_lbl.setStyleSheet(f"font-size: 14px; font-weight: 700; color: {TEXT_PRIMARY}; margin-bottom: 6px;")
        t_layout.addWidget(t_lbl)

        table = QTableWidget(3, 3, table_frame)
        table.setHorizontalHeaderLabels(["Algorithm", "Time Complexity", "Auxiliary Space Complexity"])
        table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        table.setFixedHeight(120)
        table.setStyleSheet(f"""
            QTableWidget {{
                background-color: #FFFFFF;
                border: 1px solid {BORDER_COLOR};
                border-radius: 6px;
                font-size: 12px;
            }}
            QHeaderView::section {{
                background-color: #F8FAFC;
                color: {TEXT_SECONDARY};
                font-weight: 700;
                padding: 6px;
                border: none;
                border-bottom: 1px solid {BORDER_COLOR};
            }}
        """)

        rows = [
            ("Dijkstra", ACCENT_DIJKSTRA, "O((V + E) log V)", "O(V), excluding graph storage"),
            ("Floyd-Warshall", ACCENT_FLOYD, "O(V³)", "O(V²)"),
            ("A* (A-Star)", ACCENT_ASTAR, "O((V + E) log V)*", "O(V), excluding graph storage")
        ]

        for i, (name, color, t_comp, s_comp) in enumerate(rows):
            item_name = QTableWidgetItem(name)
            item_name.setForeground(QColor(color))
            item_name.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
            table.setItem(i, 0, item_name)

            item_time = QTableWidgetItem(t_comp)
            item_time.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
            table.setItem(i, 1, item_time)

            item_space = QTableWidgetItem(s_comp)
            item_space.setForeground(QColor(TEXT_SECONDARY))
            table.setItem(i, 2, item_space)

        t_layout.addWidget(table)
        layout.addWidget(table_frame)

        # Explanatory Educational Text Card
        text_frame = QFrame(self)
        text_frame.setProperty("class", "SectionCard")
        text_layout = QVBoxLayout(text_frame)
        text_layout.setContentsMargins(14, 14, 14, 14)

        browser = QTextBrowser(text_frame)
        browser.setStyleSheet("border: none; background: transparent; font-size: 13px; line-height: 1.5;")
        browser.setHtml(f"""
            <h3 style="color: {TEXT_PRIMARY}; margin-top:0;">Key Principles & Theoretical Definitions</h3>
            <ul>
                <li><b>V</b> = number of vertices (nodes) in the graph.</li>
                <li><b>E</b> = number of edges in the graph.</li>
                <li><b>Dijkstra's Algorithm:</b> Optimal greedy single-source shortest path algorithm using a binary min-heap priority queue. Requires non-negative edge weights. Explores nodes in strict ascending order of path distance.</li>
                <li><b>Floyd-Warshall Algorithm:</b> Dynamic programming algorithm computing all-pairs shortest paths across all vertex pairs simultaneously. Executes a triple-nested loop over all vertices (V³ iterations) regardless of edge density.</li>
                <li><b>A* Search Algorithm:</b> Heuristic-guided best-first search. Uses evaluation function <i>f(n) = g(n) + h(n)</i>. When the heuristic <i>h(n)</i> is provably admissible and consistent, A* is guaranteed to return optimal paths while pruning the search space toward the goal.</li>
            </ul>

            <h3 style="color: {TEXT_PRIMARY};">Why Theoretical Complexity ≠ Measured Runtime</h3>
            <p>
                Theoretical Big-O notation characterizes asymptotic scaling behavior as <i>V, E → ∞</i>, discarding constant factors, hardware caching, and memory locality.
                In practice:
            </p>
            <ul>
                <li>For small graph sizes (e.g. V = 8), overhead from Python bytecode interpretation, hash lookups, and heap operations dominates.</li>
                <li>Floyd-Warshall incurs low constant-factor branch penalties inside simple 2D array indexing, while A* and Dijkstra perform heap insertions and dictionary tracking.</li>
                <li>On spatial layouts with targeted heuristic guidance, A* visits fewer vertices and edges than Dijkstra, leading to measurable runtime savings on larger graphs.</li>
            </ul>
        """)
        text_layout.addWidget(browser)
        layout.addWidget(text_frame, stretch=1)
