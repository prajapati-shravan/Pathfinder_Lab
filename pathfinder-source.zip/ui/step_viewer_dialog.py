"""
Execution Step Viewer modal dialog for interactive playback of algorithm traces.
Includes step-by-step navigation, timer-based autoplay, progress scrubbing,
current distance inspect, and Floyd-Warshall intermediate distance matrix viewer.
"""

from typing import List, Optional
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QSlider, QComboBox, QFrame, QTableWidget, QTableWidgetItem,
    QHeaderView, QSplitter, QWidget, QStackedWidget
)
from PySide6.QtCore import Qt, QTimer, QRectF, QPointF
from PySide6.QtGui import QPainter, QPen, QBrush, QColor, QFont, QPixmap
from algorithms.base import AlgorithmResult, StepTrace
from graph.graph_data import GraphData
from ui.theme import (
    TEXT_PRIMARY, TEXT_SECONDARY, TEXT_MUTED, BORDER_COLOR,
    ACCENT_PATH, BG_WINDOW, BG_PANEL
)


class StepCanvasWidget(QWidget):
    """Custom canvas showing nodes and edges under the current step state."""

    def __init__(self, accent_color: str, parent=None):
        super().__init__(parent)
        self.accent_color = accent_color
        self.graph: Optional[GraphData] = None
        self.trace: Optional[StepTrace] = None
        self.source: Optional[int] = None
        self.target: Optional[int] = None
        self.setMinimumSize(450, 350)
        self.setStyleSheet("background-color: #FFFFFF; border-radius: 8px;")

    def set_state(self, graph: GraphData, trace: StepTrace, source: int, target: int):
        self.graph = graph
        self.trace = trace
        self.source = source
        self.target = target
        self.update()

    def paintEvent(self, event):
        if not self.graph or not self.graph.nodes:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)

        padding = 45.0
        w = float(self.width())
        h = float(self.height())

        xs = [pos[0] for pos in self.graph.positions.values()] if self.graph.positions else [100.0]
        ys = [pos[1] for pos in self.graph.positions.values()] if self.graph.positions else [100.0]

        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)

        span_x = (max_x - min_x) if (max_x - min_x) > 1e-4 else 1.0
        span_y = (max_y - min_y) if (max_y - min_y) > 1e-4 else 1.0

        usable_w = w - 2 * padding
        usable_h = h - 2 * padding
        scale = min(usable_w / span_x, usable_h / span_y)
        offset_x = padding + (usable_w - span_x * scale) / 2.0
        offset_y = padding + (usable_h - span_y * scale) / 2.0

        def to_screen(gx: float, gy: float) -> QPointF:
            sx = offset_x + (gx - min_x) * scale
            sy = offset_y + (gy - min_y) * scale
            return QPointF(sx, sy)

        # Trace sets
        visited_nodes = set(self.trace.visited_nodes if self.trace else [])
        relaxed_set = set((min(u, v), max(u, v)) for u, v in (self.trace.relaxed_edges if self.trace else []))
        path_set = set()
        if self.trace and len(self.trace.current_path) >= 2:
            for i in range(len(self.trace.current_path) - 1):
                u = self.trace.current_path[i]
                v = self.trace.current_path[i + 1]
                path_set.add((min(u, v), max(u, v)))

        active_edge = None
        if self.trace and self.trace.active_edge:
            u, v = self.trace.active_edge
            active_edge = (min(u, v), max(u, v))

        # 1. Draw Normal Edges
        painter.setPen(QPen(QColor("#E2E8F0"), 1.8))
        for u, v, _ in self.graph.edges:
            pair = (min(u, v), max(u, v))
            if pair not in relaxed_set and pair not in path_set and pair != active_edge:
                p1 = to_screen(*self.graph.positions.get(u, (0, 0)))
                p2 = to_screen(*self.graph.positions.get(v, (0, 0)))
                painter.drawLine(p1, p2)

        # 2. Draw Relaxed Edges (dashed)
        painter.setPen(QPen(QColor(self.accent_color), 2.2, Qt.PenStyle.DashLine))
        for u, v, _ in self.graph.edges:
            pair = (min(u, v), max(u, v))
            if pair in relaxed_set and pair not in path_set and pair != active_edge:
                p1 = to_screen(*self.graph.positions.get(u, (0, 0)))
                p2 = to_screen(*self.graph.positions.get(v, (0, 0)))
                painter.drawLine(p1, p2)

        # 3. Draw Active Edge being relaxed (bold green)
        if active_edge:
            painter.setPen(QPen(QColor("#10B981"), 3.5))
            for u, v, _ in self.graph.edges:
                pair = (min(u, v), max(u, v))
                if pair == active_edge:
                    p1 = to_screen(*self.graph.positions.get(u, (0, 0)))
                    p2 = to_screen(*self.graph.positions.get(v, (0, 0)))
                    painter.drawLine(p1, p2)

        # 4. Draw Shortest Path so far (golden amber)
        painter.setPen(QPen(QColor(ACCENT_PATH), 4.0))
        for u, v, _ in self.graph.edges:
            pair = (min(u, v), max(u, v))
            if pair in path_set:
                p1 = to_screen(*self.graph.positions.get(u, (0, 0)))
                p2 = to_screen(*self.graph.positions.get(v, (0, 0)))
                painter.drawLine(p1, p2)

        # 5. Draw Edge Weights
        painter.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        for u, v, w in self.graph.edges:
            p1 = to_screen(*self.graph.positions.get(u, (0, 0)))
            p2 = to_screen(*self.graph.positions.get(v, (0, 0)))
            mx = (p1.x() + p2.x()) / 2.0
            my = (p1.y() + p2.y()) / 2.0

            w_text = f"{int(w)}" if w.is_integer() else f"{w:.1f}"
            pw, ph = 20.0, 16.0
            prect = QRectF(mx - pw/2, my - ph/2, pw, ph)

            painter.setPen(QPen(QColor(BORDER_COLOR), 1))
            painter.setBrush(QBrush(QColor("#FFFFFF")))
            painter.drawRoundedRect(prect, 3, 3)

            painter.setPen(QPen(QColor(TEXT_PRIMARY)))
            painter.drawText(prect, Qt.AlignmentFlag.AlignCenter, w_text)

        # 6. Draw Nodes
        node_radius = 16.0
        current_node = self.trace.current_node if self.trace else None

        for node in self.graph.nodes:
            pos = to_screen(*self.graph.positions.get(node, (0, 0)))

            if node == self.source:
                fill_color = QColor("#ECFDF5")
                border_color = QColor("#10B981")
                text_color = QColor("#065F46")
            elif node == self.target:
                fill_color = QColor("#FEF2F2")
                border_color = QColor("#EF4444")
                text_color = QColor("#991B1B")
            elif node in visited_nodes:
                fill_color = QColor(self.accent_color).lighter(180)
                border_color = QColor(self.accent_color)
                text_color = QColor(TEXT_PRIMARY)
            else:
                fill_color = QColor("#E0F2FE")
                border_color = QColor("#38BDF8")
                text_color = QColor(TEXT_PRIMARY)

            # Highlight Current Active Node with pulsating outer ring
            if node == current_node:
                glow_pen = QPen(QColor(self.accent_color), 3.0)
                painter.setPen(glow_pen)
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawEllipse(pos, node_radius + 6.0, node_radius + 6.0)

            painter.setPen(QPen(border_color, 2.5))
            painter.setBrush(QBrush(fill_color))
            painter.drawEllipse(pos, node_radius, node_radius)

            painter.setPen(QPen(text_color))
            painter.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
            painter.drawText(
                QRectF(pos.x() - node_radius, pos.y() - node_radius, 2 * node_radius, 2 * node_radius),
                Qt.AlignmentFlag.AlignCenter,
                str(node)
            )

            # If A* heuristic values are present, draw a clear badge underneath the node
            if self.trace and self.trace.heuristic_values and node in self.trace.heuristic_values:
                h_val = self.trace.heuristic_values[node]
                h_badge_text = f"h={h_val:.2f}" if node != self.target else "h=0 (Goal)"
                pw, ph = 54.0, 15.0
                pill_rect = QRectF(pos.x() - pw/2, pos.y() + node_radius + 3.0, pw, ph)
                painter.setPen(QPen(QColor("#A7F3D0"), 1))
                painter.setBrush(QBrush(QColor("#ECFDF5")))
                painter.drawRoundedRect(pill_rect, 4, 4)

                painter.setPen(QPen(QColor("#065F46")))
                painter.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
                painter.drawText(pill_rect, Qt.AlignmentFlag.AlignCenter, h_badge_text)

        painter.end()


class StepViewerDialog(QDialog):
    """Rich interactive modal dialog for stepping through algorithm execution."""

    def __init__(self, result: AlgorithmResult, graph: GraphData, accent_color: str, parent=None, initial_view: str = "auto"):
        super().__init__(parent)
        self.result = result
        self.graph = graph
        self.accent_color = accent_color
        self.initial_view = initial_view
        self.current_step_idx = 0
        self.is_playing = False

        self.setWindowTitle(f"Execution Step Viewer — {result.algorithm_name}")
        self.resize(1020, 680)
        self.setStyleSheet(f"""
            QDialog {{
                background-color: {BG_WINDOW};
            }}
            QFrame.SectionCard {{
                background-color: #FFFFFF;
                border: 1px solid {BORDER_COLOR};
                border-radius: 10px;
            }}
        """)

        # Timer for autoplay
        self.play_timer = QTimer(self)
        self.play_timer.timeout.connect(self._on_play_tick)
        self.playback_speed_ms = 800

        self._build_ui()
        self.show_step(0)

    def set_active_view(self, view_idx: int):
        """Switches between Graph View (0) and Distance Matrix View (1) with active tab styling."""
        if hasattr(self, "view_stack"):
            self.view_stack.setCurrentIndex(view_idx)
        if hasattr(self, "btn_show_graph") and hasattr(self, "btn_show_matrix"):
            if view_idx == 0:
                self.btn_show_graph.setStyleSheet(f"""
                    QPushButton {{
                        background-color: {self.accent_color};
                        color: #FFFFFF;
                        font-weight: 700;
                        padding: 6px 14px;
                        border-radius: 6px;
                        border: 1px solid {self.accent_color};
                        font-size: 12px;
                    }}
                """)
                self.btn_show_matrix.setStyleSheet(f"""
                    QPushButton {{
                        background-color: #F8FAFC;
                        color: #475569;
                        font-weight: 600;
                        padding: 6px 14px;
                        border-radius: 6px;
                        border: 1px solid {BORDER_COLOR};
                        font-size: 12px;
                    }}
                    QPushButton:hover {{
                        background-color: #F1F5F9;
                    }}
                """)
            else:
                self.btn_show_matrix.setStyleSheet(f"""
                    QPushButton {{
                        background-color: {self.accent_color};
                        color: #FFFFFF;
                        font-weight: 700;
                        padding: 6px 14px;
                        border-radius: 6px;
                        border: 1px solid {self.accent_color};
                        font-size: 12px;
                    }}
                """)
                self.btn_show_graph.setStyleSheet(f"""
                    QPushButton {{
                        background-color: #F8FAFC;
                        color: #475569;
                        font-weight: 600;
                        padding: 6px 14px;
                        border-radius: 6px;
                        border: 1px solid {BORDER_COLOR};
                        font-size: 12px;
                    }}
                    QPushButton:hover {{
                        background-color: #F1F5F9;
                    }}
                """)

    def _build_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 18, 20, 18)
        main_layout.setSpacing(14)

        # 1. Header Row
        header = QHBoxLayout()
        header.setSpacing(10)

        title = QLabel(f"Execution Steps: {self.result.algorithm_name}", self)
        title.setStyleSheet(f"font-size: 17px; font-weight: 800; color: {self.accent_color};")
        header.addWidget(title)

        self.step_counter_badge = QLabel("Step 1 of 1", self)
        self.step_counter_badge.setStyleSheet(f"""
            background-color: #EFF6FF;
            color: {self.accent_color};
            font-size: 12px;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 12px;
            border: 1px solid #BFDBFE;
        """)
        header.addWidget(self.step_counter_badge)

        header.addStretch()

        btn_close = QPushButton("Close", self)
        btn_close.setObjectName("btnCanvasControl")
        btn_close.clicked.connect(self.accept)
        header.addWidget(btn_close)

        main_layout.addLayout(header)

        # 2. Main Work Area (Splitter: Canvas/Matrix on Left, Info on Right)
        splitter = QSplitter(Qt.Orientation.Horizontal, self)

        # Left Container
        left_frame = QFrame(self)
        left_frame.setProperty("class", "SectionCard")
        left_layout = QVBoxLayout(left_frame)
        left_layout.setContentsMargins(12, 12, 12, 12)
        left_layout.setSpacing(8)

        # Stacked widget for Canvas vs Matrix (for Floyd-Warshall)
        self.view_stack = QStackedWidget(left_frame)

        self.step_canvas = StepCanvasWidget(self.accent_color, self.view_stack)
        self.view_stack.addWidget(self.step_canvas)

        # If Floyd-Warshall, also add Distance Matrix Table
        if "Floyd" in self.result.algorithm_name:
            self.matrix_widget = QWidget(self.view_stack)
            m_layout = QVBoxLayout(self.matrix_widget)
            m_layout.setContentsMargins(0, 0, 0, 0)

            self.matrix_title = QLabel("Intermediate Distance Matrix D(k)", self.matrix_widget)
            self.matrix_title.setStyleSheet(f"font-weight: 700; color: {TEXT_PRIMARY}; font-size: 13px; margin-bottom: 4px;")
            m_layout.addWidget(self.matrix_title)

            self.matrix_table = QTableWidget(self.matrix_widget)
            self.matrix_table.setStyleSheet(f"""
                QTableWidget {{
                    background-color: #FFFFFF;
                    border: 1px solid {BORDER_COLOR};
                    font-size: 12px;
                }}
                QHeaderView::section {{
                    background-color: #F8FAFC;
                    font-weight: 700;
                    color: {TEXT_PRIMARY};
                    border: 1px solid {BORDER_COLOR};
                    padding: 4px;
                }}
            """)
            m_layout.addWidget(self.matrix_table)
            self.view_stack.addWidget(self.matrix_widget)

            # View switcher tabs/buttons with clear tab styling
            view_toggle_layout = QHBoxLayout()
            self.btn_show_graph = QPushButton("🌐 Graph View", left_frame)
            self.btn_show_graph.setCursor(Qt.CursorShape.PointingHandCursor)

            self.btn_show_matrix = QPushButton("📊 Distance Matrix View", left_frame)
            self.btn_show_matrix.setCursor(Qt.CursorShape.PointingHandCursor)

            self.btn_show_graph.clicked.connect(lambda: self.set_active_view(0))
            self.btn_show_matrix.clicked.connect(lambda: self.set_active_view(1))

            view_toggle_layout.addWidget(self.btn_show_graph)
            view_toggle_layout.addWidget(self.btn_show_matrix)
            view_toggle_layout.addStretch()
            left_layout.addLayout(view_toggle_layout)

            # Default view selection
            if self.initial_view == "graph":
                self.set_active_view(0)
            else:
                self.set_active_view(1)  # Default directly to Distance Matrix View!

        left_layout.addWidget(self.view_stack)
        splitter.addWidget(left_frame)

        # Right Container: Step Information Card
        right_frame = QFrame(self)
        right_frame.setProperty("class", "SectionCard")
        right_layout = QVBoxLayout(right_frame)
        right_layout.setContentsMargins(14, 14, 14, 14)
        right_layout.setSpacing(10)

        info_header = QLabel("Step Details", right_frame)
        info_header.setStyleSheet(f"font-size: 14px; font-weight: 700; color: {TEXT_PRIMARY};")
        right_layout.addWidget(info_header)

        # Action description box
        self.desc_box = QLabel(right_frame)
        self.desc_box.setWordWrap(True)
        self.desc_box.setStyleSheet(f"""
            QLabel {{
                background-color: #F8FAFC;
                border: 1px solid {BORDER_COLOR};
                border-radius: 8px;
                padding: 10px;
                color: {TEXT_PRIMARY};
                font-size: 13px;
                line-height: 1.4;
            }}
        """)
        right_layout.addWidget(self.desc_box)

        # Current Node Row
        row_curr = QHBoxLayout()
        lbl_c = QLabel("Active Vertex:", right_frame)
        lbl_c.setStyleSheet(f"color: {TEXT_SECONDARY}; font-weight: 600;")
        self.val_curr_node = QLabel("—", right_frame)
        self.val_curr_node.setStyleSheet(f"font-weight: 700; color: {self.accent_color}; font-size: 14px;")
        row_curr.addWidget(lbl_c)
        row_curr.addWidget(self.val_curr_node)
        row_curr.addStretch()
        right_layout.addLayout(row_curr)

        # Current Path Row
        row_path = QVBoxLayout()
        lbl_p = QLabel("Current Path:", right_frame)
        lbl_p.setStyleSheet(f"color: {TEXT_SECONDARY}; font-weight: 600;")
        self.val_current_path = QLabel("—", right_frame)
        self.val_current_path.setStyleSheet("""
            background-color: #FEF3C7;
            color: #92400E;
            font-weight: 700;
            padding: 4px 8px;
            border-radius: 6px;
        """)
        row_path.addWidget(lbl_p)
        row_path.addWidget(self.val_current_path)
        right_layout.addLayout(row_path)

        # Distance Table
        is_astar = "A*" in self.result.algorithm_name
        if is_astar:
            dist_lbl = QLabel(f"Scores & Heuristic (Target: Node {self.result.target}):", right_frame)
            dist_lbl.setToolTip("f = g + h\ng = Exact distance from source\nh = Heuristic estimate to target\nf = Total priority (lowest explored first)")
        else:
            dist_lbl = QLabel(f"Distances from Source (Node {self.result.source}):", right_frame)
        dist_lbl.setStyleSheet(f"color: {TEXT_SECONDARY}; font-weight: 600;")
        right_layout.addWidget(dist_lbl)

        self.dist_table = QTableWidget(right_frame)
        if is_astar:
            self.dist_table.setColumnCount(4)
            self.dist_table.setHorizontalHeaderLabels(["Node", "g (Cost)", "h (Heur)", "f (Total)"])
        else:
            self.dist_table.setColumnCount(2)
            self.dist_table.setHorizontalHeaderLabels(["Node", "Shortest Dist"])
        self.dist_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.dist_table.verticalHeader().setVisible(False)
        self.dist_table.setStyleSheet(f"""
            QTableWidget {{
                background-color: #FFFFFF;
                border: 1px solid {BORDER_COLOR};
                border-radius: 6px;
                font-size: 12px;
            }}
        """)
        right_layout.addWidget(self.dist_table)

        splitter.addWidget(right_frame)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)
        main_layout.addWidget(splitter)

        # 3. Bottom Playback Toolbar
        control_frame = QFrame(self)
        control_frame.setProperty("class", "SectionCard")
        ctrl_layout = QHBoxLayout(control_frame)
        ctrl_layout.setContentsMargins(14, 10, 14, 10)
        ctrl_layout.setSpacing(12)

        self.btn_restart = QPushButton("Restart", control_frame)
        self.btn_restart.setObjectName("btnCanvasControl")
        self.btn_restart.clicked.connect(self._on_restart)
        ctrl_layout.addWidget(self.btn_restart)

        self.btn_prev = QPushButton("◀ Prev Step", control_frame)
        self.btn_prev.setObjectName("btnCanvasControl")
        self.btn_prev.clicked.connect(self._on_prev_step)
        ctrl_layout.addWidget(self.btn_prev)

        self.btn_play = QPushButton("▶ Play", control_frame)
        self.btn_play.setObjectName("btnPrimaryBlue")
        self.btn_play.setStyleSheet(f"background-color: {self.accent_color}; color: #FFFFFF;")
        self.btn_play.clicked.connect(self._toggle_play)
        ctrl_layout.addWidget(self.btn_play)

        self.btn_next = QPushButton("Next Step ▶", control_frame)
        self.btn_next.setObjectName("btnCanvasControl")
        self.btn_next.clicked.connect(self._on_next_step)
        ctrl_layout.addWidget(self.btn_next)

        # Scrubber Slider
        self.step_slider = QSlider(Qt.Orientation.Horizontal, control_frame)
        self.step_slider.setMinimum(0)
        total_steps = max(0, len(self.result.steps) - 1)
        self.step_slider.setMaximum(total_steps)
        self.step_slider.valueChanged.connect(self.show_step)
        ctrl_layout.addWidget(self.step_slider, stretch=1)

        # Speed Dropdown
        speed_lbl = QLabel("Speed:", control_frame)
        speed_lbl.setStyleSheet(f"color: {TEXT_SECONDARY}; font-weight: 600;")
        ctrl_layout.addWidget(speed_lbl)

        self.cmb_speed = QComboBox(control_frame)
        self.cmb_speed.addItems(["0.5x", "1.0x", "2.0x", "4.0x"])
        self.cmb_speed.setCurrentText("1.0x")
        self.cmb_speed.currentIndexChanged.connect(self._on_speed_changed)
        ctrl_layout.addWidget(self.cmb_speed)

        main_layout.addWidget(control_frame)

    def show_step(self, step_idx: int):
        if not self.result.steps:
            self.desc_box.setText("No execution trace available for this algorithm.")
            return

        step_idx = max(0, min(step_idx, len(self.result.steps) - 1))
        self.current_step_idx = step_idx
        self.step_slider.blockSignals(True)
        self.step_slider.setValue(step_idx)
        self.step_slider.blockSignals(False)

        trace = self.result.steps[step_idx]
        total_steps = len(self.result.steps)
        self.step_counter_badge.setText(f"Step {step_idx + 1} of {total_steps}")

        # Update descriptions
        self.desc_box.setText(trace.description)
        self.val_curr_node.setText(str(trace.current_node) if trace.current_node is not None else "None")
        if trace.current_path:
            self.val_current_path.setText(" → ".join(str(n) for n in trace.current_path))
        else:
            self.val_current_path.setText("None")

        # Update canvas
        self.step_canvas.set_state(
            graph=self.graph,
            trace=trace,
            source=self.result.source,
            target=self.result.target
        )

        # Update distance table / A* scores table
        is_astar = bool(trace.heuristic_values)
        nodes_sorted = sorted(list(self.graph.nodes))
        self.dist_table.setRowCount(len(nodes_sorted))

        if is_astar:
            self.dist_table.setColumnCount(4)
            self.dist_table.setHorizontalHeaderLabels(["Node", "g (Cost)", "h (Air)", "f = g+h"])
            self.dist_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
            self.dist_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
            self.dist_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
            self.dist_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
            for row, n in enumerate(nodes_sorted):
                self.dist_table.setItem(row, 0, QTableWidgetItem(f"Node {n}"))

                # g(n): cost from source
                d_val = trace.current_distances.get(n, float("inf"))
                g_str = "∞" if d_val == float("inf") else (f"{int(d_val)}" if d_val.is_integer() else f"{d_val:.2f}")
                item_g = QTableWidgetItem(g_str)
                item_g.setTextAlignment(Qt.AlignmentFlag.AlignCenter)

                # h(n): heuristic estimate to target
                h_val = trace.heuristic_values.get(n, 0.0)
                item_h = QTableWidgetItem(f"{h_val:.2f}")
                item_h.setTextAlignment(Qt.AlignmentFlag.AlignCenter)

                # f(n) = g(n) + h(n): total score
                f_val = trace.f_scores.get(n, float("inf"))
                f_str = "∞" if f_val == float("inf") else (f"{int(f_val)}" if f_val.is_integer() else f"{f_val:.2f}")
                item_f = QTableWidgetItem(f_str)
                item_f.setTextAlignment(Qt.AlignmentFlag.AlignCenter)

                if n == self.result.source:
                    item_g.setBackground(QColor("#ECFDF5"))
                    item_h.setBackground(QColor("#ECFDF5"))
                    item_f.setBackground(QColor("#ECFDF5"))
                elif n == self.result.target:
                    item_g.setBackground(QColor("#FEF2F2"))
                    item_h.setBackground(QColor("#FEF2F2"))
                    item_f.setBackground(QColor("#FEF2F2"))
                elif d_val < float("inf"):
                    item_g.setBackground(QColor("#F0FDF4"))
                    item_f.setBackground(QColor("#F0FDF4"))

                self.dist_table.setItem(row, 1, item_g)
                self.dist_table.setItem(row, 2, item_h)
                self.dist_table.setItem(row, 3, item_f)
        else:
            self.dist_table.setColumnCount(2)
            self.dist_table.setHorizontalHeaderLabels(["Node", "Shortest Dist"])
            for row, n in enumerate(nodes_sorted):
                self.dist_table.setItem(row, 0, QTableWidgetItem(f"Node {n}"))
                d_val = trace.current_distances.get(n, float("inf"))
                val_str = "∞ (Unreached)" if d_val == float("inf") else (f"{int(d_val)}" if d_val.is_integer() else f"{d_val:.2f}")
                item = QTableWidgetItem(val_str)
                item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                if n == self.result.source:
                    item.setBackground(QColor("#ECFDF5"))
                elif n == self.result.target and d_val < float("inf"):
                    item.setBackground(QColor("#FEF2F2"))
                self.dist_table.setItem(row, 1, item)

        # Update Floyd-Warshall Distance Matrix if applicable
        if hasattr(self, "matrix_table") and trace.matrix_state is not None:
            labels = trace.matrix_labels or [f"{i}" for i in range(len(trace.matrix_state))]
            n = len(trace.matrix_state)
            self.matrix_table.setRowCount(n)
            self.matrix_table.setColumnCount(n)
            self.matrix_table.setHorizontalHeaderLabels([f"Node {lbl}" for lbl in labels])
            self.matrix_table.setVerticalHeaderLabels([f"Node {lbl}" for lbl in labels])
            self.matrix_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
            self.matrix_table.verticalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)

            # Update matrix title dynamically
            if hasattr(self, "matrix_title"):
                if step_idx == 0:
                    self.matrix_title.setText("Intermediate Distance Matrix D(0) — Direct Edge Weights & Self-Loops (0)")
                elif step_idx == len(self.result.steps) - 1:
                    self.matrix_title.setText(f"Final Distance Matrix D* — Optimal All-Pairs Paths (Target Cost: {self.result.total_distance:.1f})")
                else:
                    k_val = trace.current_node if trace.current_node is not None else "?"
                    self.matrix_title.setText(f"Intermediate Distance Matrix D({k_val}) — Allowing Intermediate Vertex {k_val}")

            curr_node = trace.current_node
            k_idx = labels.index(curr_node) if curr_node in labels else None

            for i in range(n):
                for j in range(n):
                    val = trace.matrix_state[i][j]
                    val_str = "∞" if val == float("inf") else (f"{int(val)}" if val.is_integer() else f"{val:.1f}")
                    item = QTableWidgetItem(val_str)
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)

                    font = QFont("Segoe UI", 11)
                    if i == j:
                        # Diagonal element (self-distance = 0)
                        item.setBackground(QColor("#F1F5F9"))
                        item.setForeground(QBrush(QColor(TEXT_MUTED)))
                        font.setBold(True)
                    elif k_idx is not None and (i == k_idx or j == k_idx):
                        # Row or column of active intermediate vertex k
                        item.setBackground(QColor("#EDE9FE"))
                        item.setForeground(QBrush(QColor("#5B21B6")))
                        font.setBold(True)
                    elif val < float("inf"):
                        item.setBackground(QColor("#F5F3FF"))
                        item.setForeground(QBrush(QColor(TEXT_PRIMARY)))
                    else:
                        item.setForeground(QBrush(QColor("#94A3B8")))

                    item.setFont(font)
                    self.matrix_table.setItem(i, j, item)

    def _on_next_step(self):
        if self.current_step_idx < len(self.result.steps) - 1:
            self.show_step(self.current_step_idx + 1)
        else:
            self._pause()

    def _on_prev_step(self):
        if self.current_step_idx > 0:
            self.show_step(self.current_step_idx - 1)

    def _on_restart(self):
        self._pause()
        self.show_step(0)

    def _toggle_play(self):
        if self.is_playing:
            self._pause()
        else:
            self._play()

    def _play(self):
        if self.current_step_idx >= len(self.result.steps) - 1:
            self.show_step(0)
        self.is_playing = True
        self.btn_play.setText("⏸ Pause")
        self.play_timer.start(self.playback_speed_ms)

    def _pause(self):
        self.is_playing = False
        self.btn_play.setText("▶ Play")
        self.play_timer.stop()

    def _on_play_tick(self):
        if self.current_step_idx < len(self.result.steps) - 1:
            self.show_step(self.current_step_idx + 1)
        else:
            self._pause()

    def _on_speed_changed(self, index: int):
        speeds = [1200, 700, 350, 150]
        self.playback_speed_ms = speeds[index] if index < len(speeds) else 700
        if self.is_playing:
            self.play_timer.setInterval(self.playback_speed_ms)

    def closeEvent(self, event):
        self.play_timer.stop()
        super().closeEvent(event)
