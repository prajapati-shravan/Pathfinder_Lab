"""
Algorithm Comparison Table widget displaying comparative metrics.
"""

from typing import Dict, Optional
from PySide6.QtWidgets import (
    QFrame, QVBoxLayout, QHBoxLayout, QLabel, QTableWidget, QTableWidgetItem, QHeaderView
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPixmap, QPen, QBrush
from algorithms.base import AlgorithmResult
from benchmark.benchmark_runner import BenchmarkReport
from ui.theme import (
    TEXT_PRIMARY, TEXT_SECONDARY, BORDER_COLOR,
    ACCENT_DIJKSTRA, ACCENT_FLOYD, ACCENT_ASTAR, TEXT_SUCCESS
)


class ComparisonTableWidget(QFrame):
    """Panel containing the comparison table for all three algorithms."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("ComparisonTablePanel")
        self.setStyleSheet(f"""
            QFrame#ComparisonTablePanel {{
                background-color: #FFFFFF;
                border: 1px solid {BORDER_COLOR};
                border-radius: 12px;
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 16)
        layout.setSpacing(10)

        # Header Title
        title_box = QHBoxLayout()
        title_box.setSpacing(8)

        icon_lbl = QLabel(self)
        icon_lbl.setPixmap(self._make_chart_icon())
        title_box.addWidget(icon_lbl)

        title_lbl = QLabel("Algorithm Comparison", self)
        title_lbl.setStyleSheet(f"font-size: 14px; font-weight: 700; color: {TEXT_PRIMARY};")
        title_box.addWidget(title_lbl)
        title_box.addStretch()

        layout.addLayout(title_box)

        # Table Widget
        self.table = QTableWidget(3, 6, self)
        self.table.setHorizontalHeaderLabels([
            "Algorithm", "Path Distance", "Execution Time (ms)",
            "Nodes Visited", "Edges Examined", "Theoretical Time Complexity"
        ])

        # Column widths & stretch
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)

        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        self.table.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.table.setFixedHeight(125)

        self.table.setStyleSheet(f"""
            QTableWidget {{
                background-color: #FFFFFF;
                border: 1px solid {BORDER_COLOR};
                border-radius: 8px;
                gridline-color: #F1F5F9;
            }}
            QHeaderView::section {{
                background-color: #F8FAFC;
                color: {TEXT_SECONDARY};
                font-size: 12px;
                font-weight: 600;
                padding: 6px 12px;
                border: none;
                border-bottom: 1px solid {BORDER_COLOR};
            }}
        """)

        layout.addWidget(self.table)
        self.populate_initial_rows()

    def populate_initial_rows(self):
        algos = [
            ("Dijkstra", ACCENT_DIJKSTRA, "O((V + E) log V)"),
            ("Floyd-Warshall", ACCENT_FLOYD, "O(V³)"),
            ("A* (A-Star)", ACCENT_ASTAR, "O((V + E) log V)")
        ]
        for row, (name, color, comp) in enumerate(algos):
            # Algorithm Name with color square icon
            name_item = QTableWidgetItem(f"   {name}")
            name_item.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
            name_item.setForeground(QColor(color))
            name_item.setIcon(self._make_color_bullet(color))
            self.table.setItem(row, 0, name_item)

            # Distance
            dist_item = QTableWidgetItem("—")
            dist_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 1, dist_item)

            # Time
            time_item = QTableWidgetItem("—")
            time_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 2, time_item)

            # Nodes Visited
            nodes_item = QTableWidgetItem("—")
            nodes_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 3, nodes_item)

            # Edges Examined
            edges_item = QTableWidgetItem("—")
            edges_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 4, edges_item)

            # Complexity
            comp_item = QTableWidgetItem(comp)
            comp_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            comp_item.setForeground(QColor(TEXT_SECONDARY))
            self.table.setItem(row, 5, comp_item)

    def update_with_report(self, report: BenchmarkReport):
        d_res = report.results.get("Dijkstra")
        fw_res = report.results.get("Floyd-Warshall")
        a_res = report.results.get("A*")

        # Find fastest execution time among valid results
        min_time = min(report.median_times_ms.values()) if report.median_times_ms else None

        rows_data = [
            (0, d_res, report.median_times_ms.get("Dijkstra", 0.0), str(d_res.nodes_visited if d_res else "—"), str(d_res.edges_examined if d_res else "—")),
            (1, fw_res, report.median_times_ms.get("Floyd-Warshall", 0.0), str(fw_res.nodes_visited if fw_res else "—"), "All Pairs"),
            (2, a_res, report.median_times_ms.get("A*", 0.0), str(a_res.nodes_visited if a_res else "—"), str(a_res.edges_examined if a_res else "—")),
        ]

        for row, res, med_time, nodes_txt, edges_txt in rows_data:
            if res and res.has_path:
                d_val = f"{int(res.total_distance)}" if res.total_distance.is_integer() else f"{res.total_distance:.2f}"
                self.table.item(row, 1).setText(d_val)
            else:
                self.table.item(row, 1).setText("No Path" if res else "—")

            # Time item
            time_str = f"{med_time:.3f}"
            t_item = self.table.item(row, 2)
            t_item.setText(time_str)

            # Highlight fastest time in bold green
            if min_time is not None and med_time == min_time and not report.is_noise_level:
                t_item.setForeground(QColor(TEXT_SUCCESS))
                t_item.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
            else:
                t_item.setForeground(QColor(TEXT_PRIMARY))
                t_item.setFont(QFont("Segoe UI", 10, QFont.Weight.Normal))

            self.table.item(row, 3).setText(nodes_txt)
            self.table.item(row, 4).setText(edges_txt)

    def reset_table(self):
        self.populate_initial_rows()

    def _make_color_bullet(self, color_hex: str) -> QPixmap:
        pix = QPixmap(10, 10)
        pix.fill(Qt.GlobalColor.transparent)
        p = QPainter(pix)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setBrush(QBrush(QColor(color_hex)))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawRoundedRect(0, 0, 10, 10, 2, 2)
        p.end()
        return pix

    def _make_chart_icon(self) -> QPixmap:
        pix = QPixmap(20, 20)
        pix.fill(Qt.GlobalColor.transparent)
        p = QPainter(pix)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setBrush(QBrush(QColor("#2563EB")))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawRoundedRect(2, 8, 4, 10, 1, 1)
        p.drawRoundedRect(8, 4, 4, 14, 1, 1)
        p.drawRoundedRect(14, 11, 4, 7, 1, 1)
        p.end()
        return pix
