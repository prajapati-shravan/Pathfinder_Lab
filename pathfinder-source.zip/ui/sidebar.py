"""
Left Sidebar widget providing input controls for graph parameters and comparison execution.
"""

from typing import List, Optional
from PySide6.QtWidgets import (
    QFrame, QVBoxLayout, QHBoxLayout, QLabel,
    QSpinBox, QComboBox, QPushButton
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPainter, QPen, QBrush, QColor, QPixmap
from ui.theme import (
    TEXT_PRIMARY, TEXT_SECONDARY, BORDER_COLOR
)


class SidebarWidget(QFrame):
    """Fixed-width sidebar panel with graph configuration and action buttons."""

    generate_graph_clicked = Signal(int, int, int)  # num_nodes, source, target
    run_comparison_clicked = Signal(int, int)       # source, target
    reset_clicked = Signal()
    source_target_changed = Signal(int, int)        # source, target

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("SidebarWidget")
        self.setFixedWidth(230)
        self.setStyleSheet(f"""
            QFrame#SidebarWidget {{
                background-color: #FFFFFF;
                border: 1px solid {BORDER_COLOR};
                border-radius: 12px;
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(14)

        # 1. Title Header
        title_box = QHBoxLayout()
        title_box.setSpacing(8)

        icon_lbl = QLabel(self)
        icon_lbl.setPixmap(self._make_inputs_icon())
        title_box.addWidget(icon_lbl)

        title_lbl = QLabel("Graph Inputs", self)
        title_lbl.setStyleSheet(f"font-size: 15px; font-weight: 700; color: {TEXT_PRIMARY};")
        title_box.addWidget(title_lbl)
        title_box.addStretch()

        layout.addLayout(title_box)

        # 2. Number of Nodes
        lbl_nodes = QLabel("Number of Nodes", self)
        lbl_nodes.setStyleSheet(f"font-size: 13px; font-weight: 600; color: {TEXT_PRIMARY}; margin-top: 4px;")
        layout.addWidget(lbl_nodes)

        self.spin_nodes = QSpinBox(self)
        self.spin_nodes.setRange(2, 100)
        self.spin_nodes.setValue(8)
        self.spin_nodes.setFixedHeight(36)
        self.spin_nodes.valueChanged.connect(self._on_node_count_spin_changed)
        layout.addWidget(self.spin_nodes)

        lbl_hint = QLabel("(2 - 100)", self)
        lbl_hint.setStyleSheet(f"font-size: 11px; color: {TEXT_SECONDARY}; margin-top: -6px;")
        layout.addWidget(lbl_hint)

        # 3. Source Node
        lbl_source = QLabel("Source Node", self)
        lbl_source.setStyleSheet(f"font-size: 13px; font-weight: 600; color: {TEXT_PRIMARY}; margin-top: 4px;")
        layout.addWidget(lbl_source)

        self.cmb_source = QComboBox(self)
        self.cmb_source.setFixedHeight(36)
        self.cmb_source.currentIndexChanged.connect(self._on_selection_changed)
        layout.addWidget(self.cmb_source)

        # 4. Target Node
        lbl_target = QLabel("Target Node", self)
        lbl_target.setStyleSheet(f"font-size: 13px; font-weight: 600; color: {TEXT_PRIMARY}; margin-top: 4px;")
        layout.addWidget(lbl_target)

        self.cmb_target = QComboBox(self)
        self.cmb_target.setFixedHeight(36)
        self.cmb_target.currentIndexChanged.connect(self._on_selection_changed)
        layout.addWidget(self.cmb_target)

        layout.addSpacing(10)

        # 5. Buttons
        self.btn_generate = QPushButton("⚙ Generate Graph", self)
        self.btn_generate.setObjectName("btnPrimaryBlue")
        self.btn_generate.setFixedHeight(40)
        self.btn_generate.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_generate.clicked.connect(self._on_generate_clicked)
        layout.addWidget(self.btn_generate)

        self.btn_run = QPushButton("▶ Run Comparison", self)
        self.btn_run.setObjectName("btnPrimaryGreen")
        self.btn_run.setFixedHeight(40)
        self.btn_run.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_run.clicked.connect(self._on_run_clicked)
        layout.addWidget(self.btn_run)

        self.btn_reset = QPushButton("↺ Reset", self)
        self.btn_reset.setObjectName("btnReset")
        self.btn_reset.setFixedHeight(40)
        self.btn_reset.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_reset.clicked.connect(self.reset_clicked)
        layout.addWidget(self.btn_reset)

        layout.addStretch(1)

        # Initial populate
        self.update_node_options(list(range(1, 9)), default_source=1, default_target=8)

    def update_node_options(self, node_list: List[int], default_source: Optional[int] = None, default_target: Optional[int] = None):
        self.cmb_source.blockSignals(True)
        self.cmb_target.blockSignals(True)

        # Record requested selection
        req_source = default_source if default_source is not None else self.get_source_node()
        req_target = default_target if default_target is not None else self.get_target_node()

        self.cmb_source.clear()
        self.cmb_target.clear()

        for n in sorted(node_list):
            self.cmb_source.addItem(str(n), int(n))
            self.cmb_target.addItem(str(n), int(n))

        # Select source
        idx_s = self.cmb_source.findData(req_source)
        if idx_s >= 0:
            self.cmb_source.setCurrentIndex(idx_s)
        elif self.cmb_source.count() > 0:
            self.cmb_source.setCurrentIndex(0)

        # Select target
        idx_t = self.cmb_target.findData(req_target)
        if idx_t >= 0:
            self.cmb_target.setCurrentIndex(idx_t)
        elif self.cmb_target.count() > 1:
            self.cmb_target.setCurrentIndex(self.cmb_target.count() - 1)
        elif self.cmb_target.count() > 0:
            self.cmb_target.setCurrentIndex(0)

        self.cmb_source.blockSignals(False)
        self.cmb_target.blockSignals(False)

    def get_source_node(self) -> int:
        data = self.cmb_source.currentData()
        if data is not None:
            try:
                return int(data)
            except (ValueError, TypeError):
                pass
        txt = self.cmb_source.currentText()
        if txt:
            try:
                return int(txt)
            except ValueError:
                pass
        return 1

    def get_target_node(self) -> int:
        data = self.cmb_target.currentData()
        if data is not None:
            try:
                return int(data)
            except (ValueError, TypeError):
                pass
        txt = self.cmb_target.currentText()
        if txt:
            try:
                return int(txt)
            except ValueError:
                pass
        return 2

    def _on_node_count_spin_changed(self, val: int):
        current_s = self.get_source_node()
        current_t = self.get_target_node()
        s = current_s if 1 <= current_s <= val else 1
        if 1 <= current_t <= val and current_t != s:
            t = current_t
        else:
            t = val if val != s else 2
        self.update_node_options(list(range(1, val + 1)), default_source=s, default_target=t)
        self._on_selection_changed()

    def _on_selection_changed(self):
        s = self.get_source_node()
        t = self.get_target_node()
        self.source_target_changed.emit(s, t)

    def _on_generate_clicked(self):
        num_nodes = self.spin_nodes.value()
        s = self.get_source_node()
        t = self.get_target_node()
        self.generate_graph_clicked.emit(num_nodes, s, t)

    def _on_run_clicked(self):
        s = self.get_source_node()
        t = self.get_target_node()
        self.run_comparison_clicked.emit(s, t)

    def _make_inputs_icon(self) -> QPixmap:
        pix = QPixmap(20, 20)
        pix.fill(Qt.GlobalColor.transparent)
        p = QPainter(pix)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(QPen(QColor("#2563EB"), 2))
        p.drawEllipse(3, 3, 14, 14)
        p.setBrush(QBrush(QColor("#2563EB")))
        p.drawEllipse(7, 7, 6, 6)
        p.end()
        return pix
