"""
Fastest Algorithm Panel displaying winning algorithm, benchmark metrics,
time savings, and empirical explanation.
"""

from typing import Optional
from PySide6.QtWidgets import QFrame, QVBoxLayout, QHBoxLayout, QLabel
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QColor
from benchmark.benchmark_runner import BenchmarkReport
from ui.theme import (
    TEXT_PRIMARY, TEXT_SECONDARY, BORDER_COLOR,
    ACCENT_PATH, create_trophy_icon
)


class FastestAlgorithmPanel(QFrame):
    """Panel highlighting the statistically measured fastest algorithm for the current test."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("FastestAlgorithmPanel")
        self.setStyleSheet(f"""
            QFrame#FastestAlgorithmPanel {{
                background-color: #FFFDF5;
                border: 1.5px solid #FDE68A;
                border-radius: 12px;
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 10, 14, 10)
        layout.setSpacing(3)

        # Header with Trophy Icon
        header = QHBoxLayout()
        header.setSpacing(8)

        trophy_lbl = QLabel(self)
        trophy_lbl.setPixmap(create_trophy_icon().pixmap(18, 18))
        header.addWidget(trophy_lbl)

        title = QLabel("Fastest Algorithm (Current Test)", self)
        title.setStyleSheet("font-size: 13px; font-weight: 700; color: #D97706;")
        header.addWidget(title)
        header.addStretch()

        layout.addLayout(header)

        # Main Winner Name
        self.lbl_winner = QLabel("Pending Comparison", self)
        self.lbl_winner.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_winner.setStyleSheet("font-size: 18px; font-weight: 800; color: #047857; margin-top: 2px;")
        layout.addWidget(self.lbl_winner)

        # Execution Time Subtitle
        self.lbl_time = QLabel("Execution Time: —", self)
        self.lbl_time.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_time.setStyleSheet(f"font-size: 12px; font-weight: 600; color: {TEXT_PRIMARY};")
        layout.addWidget(self.lbl_time)

        # Details: Trials & Savings
        self.lbl_details = QLabel("Run comparison to benchmark algorithms", self)
        self.lbl_details.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_details.setStyleSheet(f"font-size: 11px; color: {TEXT_SECONDARY};")
        layout.addWidget(self.lbl_details)

        # Explanation sentence
        self.lbl_explanation = QLabel("", self)
        self.lbl_explanation.setWordWrap(True)
        self.lbl_explanation.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_explanation.setStyleSheet(f"font-size: 11px; color: {TEXT_SECONDARY}; font-style: italic; margin-top: 2px;")
        layout.addWidget(self.lbl_explanation)

    def update_report(self, report: BenchmarkReport):
        if not report.distances_agree:
            self.lbl_winner.setText("Results Disagree")
            self.lbl_winner.setStyleSheet("font-size: 18px; font-weight: 800; color: #DC2626;")
            self.lbl_time.setText("Correctness Check Failed")
            self.lbl_details.setText("Algorithms produced differing shortest-path distances.")
            self.lbl_explanation.setText("Winner selection disabled until all algorithms agree.")
            return

        if report.is_noise_level:
            self.lbl_winner.setText("No reliable performance winner at this test size.")
            self.lbl_winner.setStyleSheet("font-size: 13px; font-weight: 700; color: #D97706; margin-top: 2px;")
            self.lbl_time.setText("Difference within noise threshold (<0.005 ms / <5%)")
            self.lbl_details.setText(f"Benchmark: {report.trials_count} trials on same immutable graph")
            self.lbl_explanation.setText("No reliable performance winner at this test size.")
            return

        winner = report.winner_name or "Unknown"
        self.lbl_winner.setText(winner)
        self.lbl_winner.setStyleSheet("font-size: 20px; font-weight: 800; color: #047857;")

        self.lbl_time.setText(f"Execution Time: {report.winner_time_ms:.3f} ms")
        self.lbl_details.setText(
            f"Saved {report.time_saved_ms:.3f} ms ({report.time_saved_pct}%) vs {report.slowest_name} ({report.trials_count} trials)"
        )
        self.lbl_explanation.setText(report.explanation)

    def reset_state(self):
        self.lbl_winner.setText("Pending Comparison")
        self.lbl_winner.setStyleSheet("font-size: 18px; font-weight: 700; color: #64748B;")
        self.lbl_time.setText("Execution Time: —")
        self.lbl_details.setText("Run comparison to benchmark algorithms")
        self.lbl_explanation.setText("")
