"""
Algorithm card widget displaying execution metrics, mini graph preview,
and execution step viewer button.
"""

from typing import Optional, List, Tuple
from PySide6.QtWidgets import (
    QFrame, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QWidget
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPainter, QPen, QBrush, QColor, QPixmap, QFont
from algorithms.base import AlgorithmResult
from graph.graph_data import GraphData
from ui.mini_graph_view import MiniGraphWidget
from ui.theme import (
    TEXT_PRIMARY, TEXT_SECONDARY, TEXT_MUTED, BORDER_COLOR,
    ACCENT_PATH, BG_SUCCESS, TEXT_SUCCESS
)


class AlgorithmCard(QFrame):
    """Card widget for Dijkstra, Floyd-Warshall, or A*."""

    view_steps_clicked = Signal(str)  # algorithm_name

    def __init__(
        self,
        algorithm_name: str,
        accent_color: str,
        button_id: str,
        parent=None
    ):
        super().__init__(parent)
        self.algorithm_name = algorithm_name
        self.accent_color = accent_color
        self.button_id = button_id
        self.current_result: Optional[AlgorithmResult] = None

        clean_name = "".join(c if c.isalnum() else "_" for c in algorithm_name)
        self.setObjectName(f"Card_{clean_name}")
        self.setStyleSheet(f"""
            QFrame#{self.objectName()} {{
                background-color: #FFFFFF;
                border: 1.5px solid {accent_color};
                border-radius: 12px;
            }}
            QFrame#{self.objectName()} QLabel {{
                border: none;
                background-color: transparent;
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 10, 14, 10)
        layout.setSpacing(6)

        # 1. Header: Icon + Title + Status Badge
        header = QHBoxLayout()
        header.setSpacing(8)

        icon_lbl = QLabel(self)
        icon_lbl.setPixmap(self._make_algo_icon())
        header.addWidget(icon_lbl)

        title_lbl = QLabel(algorithm_name, self)
        title_lbl.setStyleSheet(f"font-size: 14px; font-weight: 700; color: {accent_color};")
        header.addWidget(title_lbl)

        header.addStretch()

        self.status_badge = QLabel("Ready", self)
        self._set_badge_style("Ready")
        header.addWidget(self.status_badge)

        layout.addLayout(header)

        # 2. Metrics Rows Container
        self.metrics_container = QVBoxLayout()
        self.metrics_container.setSpacing(3)

        # Row 1: Shortest Path
        self.lbl_path = QLabel("—", self)
        self.row_path = self._add_metric_row("Shortest Path", self.lbl_path, is_path_pill=True)
        self.metrics_container.addLayout(self.row_path)

        # Row 2: Total Distance
        self.lbl_distance = QLabel("—", self)
        self.lbl_distance.setStyleSheet(f"font-weight: 700; color: {TEXT_PRIMARY};")
        self.metrics_container.addLayout(self._add_metric_row("Total Distance", self.lbl_distance))

        # Row 3: Execution Time
        self.lbl_time = QLabel("—", self)
        self.lbl_time.setStyleSheet(f"font-weight: 700; color: {TEXT_PRIMARY};")
        self.metrics_container.addLayout(self._add_metric_row("Execution Time", self.lbl_time))

        # Row 4: Nodes Visited / Expanded
        self.lbl_nodes_title = QLabel("Nodes Visited", self)
        self.lbl_nodes_title.setStyleSheet(f"color: {TEXT_SECONDARY}; font-size: 12px;")
        self.lbl_nodes_val = QLabel("—", self)
        self.lbl_nodes_val.setStyleSheet(f"font-weight: 700; color: {TEXT_PRIMARY};")
        self.row_nodes = QHBoxLayout()
        self.row_nodes.addWidget(self.lbl_nodes_title)
        self.row_nodes.addStretch()
        self.row_nodes.addWidget(self.lbl_nodes_val)
        self.metrics_container.addLayout(self.row_nodes)

        # Row 5: Edges Examined / Matrix Updates
        self.lbl_edges_title = QLabel("Edges Examined", self)
        self.lbl_edges_title.setStyleSheet(f"color: {TEXT_SECONDARY}; font-size: 12px;")
        self.lbl_edges_val = QLabel("—", self)
        self.lbl_edges_val.setStyleSheet(f"font-weight: 700; color: {TEXT_PRIMARY};")
        self.row_edges = QHBoxLayout()
        self.row_edges.addWidget(self.lbl_edges_title)
        self.row_edges.addStretch()
        self.row_edges.addWidget(self.lbl_edges_val)
        self.metrics_container.addLayout(self.row_edges)

        layout.addLayout(self.metrics_container)

        # 3. Mini Graph Canvas Preview
        self.mini_graph = MiniGraphWidget(accent_color, self)
        layout.addWidget(self.mini_graph)

        # 4. View Execution Steps Button
        self.btn_steps = QPushButton("⚲ View Execution Steps", self)
        self.btn_steps.setObjectName(button_id)
        self.btn_steps.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_steps.clicked.connect(lambda: self.view_steps_clicked.emit(self.algorithm_name))
        layout.addWidget(self.btn_steps)

        # Custom labels for Floyd-Warshall
        if "Floyd" in algorithm_name:
            self.lbl_nodes_title.setText("Matrix Updates")
            self.lbl_edges_title.setText("Status")
            self.btn_steps.setText("📊 View Distance Matrix & Steps")
            self.btn_steps.setToolTip("Inspect the interactive All-Pairs Distance Matrix D(k) step-by-step")

    def _add_metric_row(self, label_text: str, value_widget: QWidget, is_path_pill: bool = False) -> QHBoxLayout:
        row = QHBoxLayout()
        lbl = QLabel(label_text, self)
        lbl.setStyleSheet(f"color: {TEXT_SECONDARY}; font-size: 12px;")
        row.addWidget(lbl)
        row.addStretch()

        if is_path_pill:
            value_widget.setStyleSheet(f"""
                QLabel {{
                    background-color: #FEF3C7;
                    color: #92400E;
                    font-weight: 700;
                    font-size: 12px;
                    padding: 3px 8px;
                    border-radius: 6px;
                }}
            """)
        row.addWidget(value_widget)
        return row

    def _set_badge_style(self, status: str):
        if status == "Completed":
            self.status_badge.setText("● Completed")
            self.status_badge.setStyleSheet(f"""
                QLabel {{
                    background-color: {BG_SUCCESS};
                    color: {TEXT_SUCCESS};
                    font-weight: 600;
                    font-size: 11px;
                    padding: 3px 8px;
                    border-radius: 10px;
                }}
            """)
        elif status == "No Path":
            self.status_badge.setText("● No Path")
            self.status_badge.setStyleSheet("""
                QLabel {
                    background-color: #FEE2E2;
                    color: #991B1B;
                    font-weight: 600;
                    font-size: 11px;
                    padding: 3px 8px;
                    border-radius: 10px;
                }
            """)
        else:
            self.status_badge.setText("● Ready")
            self.status_badge.setStyleSheet("""
                QLabel {
                    background-color: #F1F5F9;
                    color: #64748B;
                    font-weight: 600;
                    font-size: 11px;
                    padding: 3px 8px;
                    border-radius: 10px;
                }
            """)

    def update_result(self, result: AlgorithmResult, graph: GraphData):
        self.current_result = result
        self._set_badge_style(result.status)

        if result.has_path:
            self.lbl_path.setText(result.path_string)
            dist_str = f"{int(result.total_distance)}" if result.total_distance.is_integer() else f"{result.total_distance:.2f}"
            self.lbl_distance.setText(dist_str)
        else:
            self.lbl_path.setText("No Path")
            self.lbl_distance.setText("—")

        self.lbl_time.setText(f"{result.execution_time_ms:.3f} ms")

        if "Floyd" in self.algorithm_name:
            self.lbl_nodes_val.setText(str(result.matrix_updates))
            self.lbl_edges_val.setText(result.status)
        else:
            self.lbl_nodes_val.setText(str(result.nodes_visited))
            self.lbl_edges_val.setText(str(result.edges_examined))

        # Update mini graph
        self.mini_graph.set_data(
            graph=graph,
            source=result.source,
            target=result.target,
            shortest_path=result.path,
            explored_edges=result.explored_edges
        )

    def reset_state(self, graph: Optional[GraphData] = None, source: Optional[int] = None, target: Optional[int] = None):
        self.current_result = None
        self._set_badge_style("Ready")
        self.lbl_path.setText("—")
        self.lbl_distance.setText("—")
        self.lbl_time.setText("—")
        self.lbl_nodes_val.setText("—")
        self.lbl_edges_val.setText("—")
        if graph:
            self.mini_graph.set_data(graph, source, target, [], [])

    def _make_algo_icon(self) -> QPixmap:
        pix = QPixmap(20, 20)
        pix.fill(Qt.GlobalColor.transparent)
        p = QPainter(pix)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(QPen(QColor(self.accent_color), 2))
        p.drawLine(3, 10, 10, 4)
        p.drawLine(10, 4, 17, 10)
        p.drawLine(10, 4, 10, 16)

        p.setBrush(QBrush(QColor(self.accent_color)))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(1, 8, 4, 4)
        p.drawEllipse(8, 2, 4, 4)
        p.drawEllipse(15, 8, 4, 4)
        p.drawEllipse(8, 14, 4, 4)
        p.end()
        return pix
