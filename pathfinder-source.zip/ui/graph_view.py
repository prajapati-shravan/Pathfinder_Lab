"""
Interactive 2D Graph Canvas using QGraphicsView and QGraphicsScene.
Features draggable nodes, edge weight pill labels, shortest path glow,
zoom/pan/fit controls, and real-time layout updating.
"""

import math
from typing import Dict, List, Tuple, Optional, Set
from PySide6.QtWidgets import (
    QGraphicsView, QGraphicsScene, QGraphicsItem,
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QCheckBox, QFrame, QGraphicsDropShadowEffect
)
from PySide6.QtCore import Qt, QRectF, QPointF, Signal
from PySide6.QtGui import (
    QPainter, QPen, QBrush, QColor, QFont, QCursor, QPainterPath, QPixmap
)
from graph.graph_data import GraphData
from ui.theme import (
    TEXT_PRIMARY, TEXT_SECONDARY, TEXT_MUTED, BORDER_COLOR,
    ACCENT_PATH, ACCENT_DIJKSTRA, ACCENT_FLOYD, ACCENT_ASTAR,
    NODE_SOURCE_FILL, NODE_SOURCE_BORDER,
    NODE_TARGET_FILL, NODE_TARGET_BORDER,
    NODE_NORMAL_FILL, NODE_NORMAL_BORDER,
    EDGE_NORMAL
)


class NodeGraphicsItem(QGraphicsItem):
    """Interactive circular node item supporting dragging and dynamic styling."""

    def __init__(self, node_id: int, x: float, y: float, parent_view: "GraphView"):
        super().__init__()
        self.node_id = node_id
        self.radius = 18.0
        self.parent_view = parent_view
        self.role = "normal"  # "source", "target", "normal", "path", "visited"
        
        self.setPos(x, y)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, True)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemSendsGeometryChanges, True)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, True)
        self.setAcceptHoverEvents(True)
        self.setCursor(Qt.CursorShape.OpenHandCursor)
        self.setZValue(10)

    def boundingRect(self) -> QRectF:
        r = self.radius + 6.0
        return QRectF(-r, -r, 2 * r, 2 * r)

    def paint(self, painter: QPainter, option, widget=None):
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Style by role
        if self.role == "source":
            fill_color = QColor(NODE_SOURCE_FILL)
            border_color = QColor(NODE_SOURCE_BORDER)
            text_color = QColor("#065F46")
            border_width = 3.0
        elif self.role == "target":
            fill_color = QColor(NODE_TARGET_FILL)
            border_color = QColor(NODE_TARGET_BORDER)
            text_color = QColor("#991B1B")
            border_width = 3.0
        elif self.role == "path":
            fill_color = QColor("#FEF3C7")
            border_color = QColor(ACCENT_PATH)
            text_color = QColor("#92400E")
            border_width = 3.0
        else:
            fill_color = QColor(NODE_NORMAL_FILL)
            border_color = QColor(NODE_NORMAL_BORDER)
            text_color = QColor(TEXT_PRIMARY)
            border_width = 2.4

        # Draw subtle drop shadow/glow
        glow_pen = QPen(border_color.lighter(130), border_width + 2)
        painter.setPen(glow_pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawEllipse(QPointF(0, 0), self.radius + 1.0, self.radius + 1.0)

        # Draw Node Circle
        painter.setPen(QPen(border_color, border_width))
        painter.setBrush(QBrush(fill_color))
        painter.drawEllipse(QPointF(0, 0), self.radius, self.radius)

        # Draw Node ID text
        painter.setPen(QPen(text_color))
        font = QFont("Segoe UI", 11, QFont.Weight.Bold)
        painter.setFont(font)
        painter.drawText(
            QRectF(-self.radius, -self.radius, 2 * self.radius, 2 * self.radius),
            Qt.AlignmentFlag.AlignCenter,
            str(self.node_id)
        )

    def itemChange(self, change, value):
        if change == QGraphicsItem.GraphicsItemChange.ItemPositionHasChanged:
            # Update edges connected to this node in real time
            self.parent_view.on_node_moved(self.node_id, self.pos())
        return super().itemChange(change, value)

    def mousePressEvent(self, event):
        self.setCursor(Qt.CursorShape.ClosedHandCursor)
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        self.setCursor(Qt.CursorShape.OpenHandCursor)
        super().mouseReleaseEvent(event)


class EdgeGraphicsItem(QGraphicsItem):
    """Draws connecting lines and edge weights."""

    def __init__(
        self,
        u_item: NodeGraphicsItem,
        v_item: NodeGraphicsItem,
        weight: float,
        parent_view: "GraphView"
    ):
        super().__init__()
        self.u_item = u_item
        self.v_item = v_item
        self.weight = weight
        self.parent_view = parent_view
        self.state = "normal"  # "normal", "path", "explored_blue", "explored_purple", "explored_green", "relaxed"
        self.setZValue(2)

    def boundingRect(self) -> QRectF:
        p1 = self.u_item.pos()
        p2 = self.v_item.pos()
        rect = QRectF(p1, p2).normalized()
        return rect.adjusted(-30, -30, 30, 30)

    def paint(self, painter: QPainter, option, widget=None):
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        p1 = self.u_item.pos()
        p2 = self.v_item.pos()

        # Edge Pen Style
        if self.state == "path":
            pen = QPen(QColor(ACCENT_PATH), 4.2)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        elif self.state == "explored_blue":
            pen = QPen(QColor(ACCENT_DIJKSTRA), 2.2, Qt.PenStyle.DashLine)
        elif self.state == "explored_purple":
            pen = QPen(QColor(ACCENT_FLOYD), 2.2, Qt.PenStyle.DashLine)
        elif self.state == "explored_green":
            pen = QPen(QColor(ACCENT_ASTAR), 2.2, Qt.PenStyle.DashLine)
        elif self.state == "relaxed":
            pen = QPen(QColor("#10B981"), 2.2, Qt.PenStyle.DashLine)
        else:
            pen = QPen(QColor("#94A3B8"), 1.8)

        painter.setPen(pen)
        painter.drawLine(p1, p2)

        # Draw weight pill if enabled
        if self.parent_view.show_weights:
            mid_x = (p1.x() + p2.x()) / 2.0
            mid_y = (p1.y() + p2.y()) / 2.0

            # Subtle normal perpendicular offset for readability
            dx = p2.x() - p1.x()
            dy = p2.y() - p1.y()
            length = math.hypot(dx, dy)
            if length > 1e-4:
                nx = -dy / length * 10.0
                ny = dx / length * 10.0
            else:
                nx, ny = 0.0, 0.0

            cx = mid_x + nx
            cy = mid_y + ny

            weight_text = f"{int(self.weight)}" if self.weight.is_integer() else f"{self.weight:.1f}"
            pill_w = 20.0 if len(weight_text) <= 2 else 26.0
            pill_h = 18.0
            pill_rect = QRectF(cx - pill_w / 2.0, cy - pill_h / 2.0, pill_w, pill_h)

            painter.setPen(QPen(QColor(BORDER_COLOR), 1.0))
            painter.setBrush(QBrush(QColor("#FFFFFF")))
            painter.drawRoundedRect(pill_rect, 4.0, 4.0)

            painter.setPen(QPen(QColor(TEXT_PRIMARY)))
            painter.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
            painter.drawText(pill_rect, Qt.AlignmentFlag.AlignCenter, weight_text)


class LegendWidget(QFrame):
    """Floating legend overlay panel placed in the top right of the graph visualization."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("LegendWidgetPanel")
        self.setStyleSheet(f"""
            QFrame#LegendWidgetPanel {{
                background-color: rgba(255, 255, 255, 0.95);
                border: 1px solid {BORDER_COLOR};
                border-radius: 8px;
            }}
            QFrame#LegendWidgetPanel QLabel {{
                border: none;
                background-color: transparent;
                font-size: 11px;
                color: {TEXT_PRIMARY};
                font-weight: 500;
            }}
            QFrame#LegendWidgetPanel QLabel#legendTitle {{
                font-size: 12px;
                font-weight: 700;
                color: {TEXT_PRIMARY};
                margin-bottom: 2px;
            }}
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(5)

        title = QLabel("Legend", self)
        title.setObjectName("legendTitle")
        layout.addWidget(title)

        items = [
            ("Source Node", NODE_SOURCE_BORDER, "circle"),
            ("Target Node", NODE_TARGET_BORDER, "circle"),
            ("Normal Node", NODE_NORMAL_BORDER, "circle"),
            ("Shortest Path", ACCENT_PATH, "line_thick"),
            ("Edge (Weight)", "#94A3B8", "line_thin"),
            ("Explored Edge", ACCENT_DIJKSTRA, "line_dash"),
            ("Relaxed Edge", "#10B981", "line_dash"),
            ("Unreachable Node", "#CBD5E1", "circle_gray"),
        ]

        for label_text, color_hex, shape in items:
            row = QHBoxLayout()
            row.setSpacing(8)

            icon_lbl = QLabel(self)
            icon_lbl.setFixedSize(20, 16)
            pix = self._draw_legend_symbol(color_hex, shape)
            icon_lbl.setPixmap(pix)

            lbl = QLabel(label_text, self)
            row.addWidget(icon_lbl)
            row.addWidget(lbl)
            row.addStretch()
            layout.addLayout(row)

    def _draw_legend_symbol(self, color_hex: str, shape: str) -> QPixmap:
        pix = QPixmap(20, 16)
        pix.fill(Qt.GlobalColor.transparent)
        p = QPainter(pix)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        if shape == "circle":
            p.setPen(QPen(QColor(color_hex), 2))
            p.setBrush(QBrush(QColor(color_hex).lighter(170)))
            p.drawEllipse(QPointF(10, 8), 5, 5)
        elif shape == "circle_gray":
            p.setPen(QPen(QColor("#94A3B8"), 1.5))
            p.setBrush(QBrush(QColor("#E2E8F0")))
            p.drawEllipse(QPointF(10, 8), 5, 5)
        elif shape == "line_thick":
            p.setPen(QPen(QColor(color_hex), 3.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            p.drawLine(2, 8, 18, 8)
        elif shape == "line_thin":
            p.setPen(QPen(QColor(color_hex), 2.0, Qt.PenStyle.SolidLine))
            p.drawLine(2, 8, 18, 8)
        elif shape == "line_dash":
            p.setPen(QPen(QColor(color_hex), 2.0, Qt.PenStyle.DashLine))
            p.drawLine(2, 8, 18, 8)

        p.end()
        return pix


class GraphView(QGraphicsView):
    """Interactive canvas widget displaying the graph."""

    node_dragged = Signal(int, float, float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.scene = QGraphicsScene(self)
        self.setScene(self.scene)
        self.setRenderHints(
            QPainter.RenderHint.Antialiasing |
            QPainter.RenderHint.TextAntialiasing |
            QPainter.RenderHint.SmoothPixmapTransform
        )
        self.setViewportUpdateMode(QGraphicsView.ViewportUpdateMode.FullViewportUpdate)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setDragMode(QGraphicsView.DragMode.NoDrag)
        self.setStyleSheet("background-color: #FFFFFF; border: none;")

        self.graph: Optional[GraphData] = None
        self.node_items: Dict[int, NodeGraphicsItem] = {}
        self.edge_items: List[EdgeGraphicsItem] = []
        self.source_node: Optional[int] = None
        self.target_node: Optional[int] = None
        self.shortest_path: List[int] = []
        self.explored_edges: List[Tuple[int, int]] = []
        self.show_weights: bool = True
        self.current_zoom: float = 1.0

    def set_graph_data(
        self,
        graph: GraphData,
        source: Optional[int] = None,
        target: Optional[int] = None,
        shortest_path: Optional[List[int]] = None,
        explored_edges: Optional[List[Tuple[int, int]]] = None
    ):
        self.graph = graph
        self.source_node = source
        self.target_node = target
        self.shortest_path = shortest_path or []
        self.explored_edges = explored_edges or []
        self.rebuild_scene()

    def rebuild_scene(self):
        self.scene.clear()
        self.node_items.clear()
        self.edge_items.clear()

        if not self.graph or not self.graph.nodes:
            return

        # 1. Add Node Items
        for node in sorted(list(self.graph.nodes)):
            x, y = self.graph.positions.get(node, (100.0 + node * 60, 200.0))
            item = NodeGraphicsItem(node, x, y, self)

            if node == self.source_node:
                item.role = "source"
            elif node == self.target_node:
                item.role = "target"
            elif node in self.shortest_path:
                item.role = "path"
            else:
                item.role = "normal"

            self.scene.addItem(item)
            self.node_items[node] = item

        # Determine path edge pairs
        path_edges = set()
        if len(self.shortest_path) >= 2:
            for i in range(len(self.shortest_path) - 1):
                u = self.shortest_path[i]
                v = self.shortest_path[i + 1]
                path_edges.add((min(u, v), max(u, v)))

        # 2. Add Edge Items
        for u, v, weight in self.graph.edges:
            if u in self.node_items and v in self.node_items:
                edge_item = EdgeGraphicsItem(
                    self.node_items[u],
                    self.node_items[v],
                    weight,
                    self
                )
                pair = (min(u, v), max(u, v))
                if pair in path_edges:
                    edge_item.state = "path"
                    edge_item.setZValue(5)
                else:
                    edge_item.state = "normal"

                self.scene.addItem(edge_item)
                self.edge_items.append(edge_item)

        # Ensure scene rect has plenty of comfortable padding
        margin = 40
        rect = self.scene.itemsBoundingRect().adjusted(-margin, -margin, margin, margin)
        self.scene.setSceneRect(rect)
        self.fit_to_screen()

    def on_node_moved(self, node_id: int, new_pos: QPointF):
        if self.graph and node_id in self.graph.positions:
            self.graph.positions[node_id] = (new_pos.x(), new_pos.y())
        for edge_item in self.edge_items:
            if edge_item.u_item.node_id == node_id or edge_item.v_item.node_id == node_id:
                edge_item.update()
        self.node_dragged.emit(node_id, new_pos.x(), new_pos.y())

    def zoom_in(self):
        self.scale(1.15, 1.15)
        self.current_zoom *= 1.15

    def zoom_out(self):
        self.scale(1 / 1.15, 1 / 1.15)
        self.current_zoom /= 1.15

    def fit_to_screen(self):
        if not self.scene.items():
            return
        self.resetTransform()
        self.current_zoom = 1.0
        margin = 40
        rect = self.scene.itemsBoundingRect().adjusted(-margin, -margin, margin, margin)
        self.setSceneRect(rect)
        self.fitInView(rect, Qt.AspectRatioMode.KeepAspectRatio)

    def toggle_weights(self, show: bool):
        self.show_weights = show
        for edge in self.edge_items:
            edge.update()


class GraphVisualizationPanel(QFrame):
    """Upper workspace card containing header controls, canvas, and legend."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("GraphVisualizationPanel")
        self.setProperty("class", "CardPanel")
        self.setStyleSheet(f"""
            QFrame#GraphVisualizationPanel {{
                background-color: #FFFFFF;
                border: 1px solid {BORDER_COLOR};
                border-radius: 12px;
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 16)
        layout.setSpacing(10)

        # Header toolbar row
        header = QHBoxLayout()
        header.setSpacing(12)

        # Title with icon
        title_box = QHBoxLayout()
        title_box.setSpacing(8)
        
        icon_lbl = QLabel(self)
        icon_lbl.setPixmap(self._make_gear_node_icon())
        title_lbl = QLabel("Graph Visualization", self)
        title_lbl.setStyleSheet(f"font-size: 14px; font-weight: 700; color: {TEXT_PRIMARY};")
        subtitle_lbl = QLabel("(Drag nodes to rearrange)", self)
        subtitle_lbl.setStyleSheet(f"font-size: 13px; font-weight: 500; color: {TEXT_SECONDARY};")

        title_box.addWidget(icon_lbl)
        title_box.addWidget(title_lbl)
        title_box.addWidget(subtitle_lbl)
        header.addLayout(title_box)

        header.addStretch()

        # Canvas Controls
        self.btn_zoom_in = QPushButton("+ Zoom In", self)
        self.btn_zoom_in.setObjectName("btnCanvasControl")
        self.btn_zoom_out = QPushButton("− Zoom Out", self)
        self.btn_zoom_out.setObjectName("btnCanvasControl")
        self.btn_fit = QPushButton("⛶ Fit", self)
        self.btn_fit.setObjectName("btnCanvasControl")
        self.btn_reset_layout = QPushButton("↺ Reset Layout", self)
        self.btn_reset_layout.setObjectName("btnCanvasControl")
        
        self.chk_show_weights = QCheckBox("Show Weights", self)
        self.chk_show_weights.setChecked(True)

        header.addWidget(self.btn_zoom_in)
        header.addWidget(self.btn_zoom_out)
        header.addWidget(self.btn_fit)
        header.addWidget(self.btn_reset_layout)
        header.addWidget(self.chk_show_weights)

        layout.addLayout(header)

        # Canvas Container with overlaid Legend
        self.canvas_container = QWidget(self)
        container_layout = QHBoxLayout(self.canvas_container)
        container_layout.setContentsMargins(0, 0, 0, 0)
        container_layout.setSpacing(8)

        self.graph_view = GraphView(self.canvas_container)
        self.graph_view.setFixedHeight(245)

        self.legend = LegendWidget(self.canvas_container)

        container_layout.addWidget(self.graph_view, stretch=1)
        container_layout.addWidget(self.legend, alignment=Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignRight)

        layout.addWidget(self.canvas_container)

        # Connect controls
        self.btn_zoom_in.clicked.connect(self.graph_view.zoom_in)
        self.btn_zoom_out.clicked.connect(self.graph_view.zoom_out)
        self.btn_fit.clicked.connect(self.graph_view.fit_to_screen)
        self.chk_show_weights.toggled.connect(self.graph_view.toggle_weights)

    def _make_gear_node_icon(self) -> QPixmap:
        pix = QPixmap(20, 20)
        pix.fill(Qt.GlobalColor.transparent)
        p = QPainter(pix)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(QPen(QColor("#2563EB"), 2))
        p.setBrush(QBrush(QColor("#EFF6FF")))
        p.drawEllipse(2, 2, 16, 16)
        p.setBrush(QBrush(QColor("#2563EB")))
        p.drawEllipse(7, 7, 6, 6)
        p.end()
        return pix
