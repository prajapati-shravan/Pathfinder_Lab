"""
Unit tests for Dijkstra, Floyd-Warshall, and A* shortest path algorithms.
"""

import pytest
from algorithms.dijkstra import dijkstra_shortest_path
from algorithms.floyd_warshall import floyd_warshall_shortest_path
from algorithms.astar import astar_shortest_path
from graph.generator import create_reference_8node_graph, generate_connected_graph
from graph.graph_data import GraphData


def test_reference_graph_path_and_distance():
    """Verify all algorithms find the exact reference shortest path [1, 3, 5, 7, 8] with distance 8.0."""
    g = create_reference_8node_graph()
    source, target = 1, 8

    dijk_res = dijkstra_shortest_path(g, source, target, record_steps=True)
    fw_res = floyd_warshall_shortest_path(g, source, target, record_steps=True)
    astar_res = astar_shortest_path(g, source, target, record_steps=True)

    expected_path = [1, 3, 5, 7, 8]
    expected_distance = 8.0

    assert dijk_res.path == expected_path
    assert dijk_res.total_distance == expected_distance
    assert dijk_res.status == "Completed"

    assert fw_res.path == expected_path
    assert fw_res.total_distance == expected_distance
    assert fw_res.status == "Completed"

    assert astar_res.path == expected_path
    assert astar_res.total_distance == expected_distance
    assert astar_res.status == "Completed"


def test_source_equals_target():
    """Verify source == target returns 0 distance and 1-element path."""
    g = create_reference_8node_graph()
    for algo in [dijkstra_shortest_path, floyd_warshall_shortest_path, astar_shortest_path]:
        res = algo(g, 4, 4, record_steps=True)
        assert res.total_distance == 0.0
        assert res.path == [4]
        assert res.status == "Completed"


def test_disconnected_graph():
    """Verify algorithms correctly detect disconnected graphs and return No Path."""
    g = GraphData()
    g.add_node(1, (10, 10))
    g.add_node(2, (20, 20))
    g.add_node(3, (30, 30))
    g.add_edge(1, 2, 5.0)  # Node 3 is disconnected

    for algo in [dijkstra_shortest_path, floyd_warshall_shortest_path, astar_shortest_path]:
        res = algo(g, 1, 3, record_steps=True)
        assert res.total_distance == float("inf")
        assert res.path == []
        assert res.status == "No Path"


@pytest.mark.parametrize("n", [5, 10, 15, 25])
def test_all_algorithms_agree_on_random_graphs(n):
    """Verify Dijkstra, Floyd-Warshall, and A* produce identical shortest-path distances on random graphs."""
    g = generate_connected_graph(num_nodes=n, seed=100 + n)
    source = 1
    target = n

    d_res = dijkstra_shortest_path(g, source, target, record_steps=False)
    fw_res = floyd_warshall_shortest_path(g, source, target, record_steps=False)
    a_res = astar_shortest_path(g, source, target, record_steps=False)

    assert d_res.has_path
    assert fw_res.has_path
    assert a_res.has_path

    # All 3 algorithms must match path distance to floating point precision
    assert pytest.approx(d_res.total_distance, rel=1e-5) == fw_res.total_distance
    assert pytest.approx(d_res.total_distance, rel=1e-5) == a_res.total_distance


def test_floyd_warshall_distance_matrix_and_current_distances():
    """Verify Floyd-Warshall includes matrix_state and current_distances at every step."""
    g = create_reference_8node_graph()
    res = floyd_warshall_shortest_path(g, source=1, target=8, record_steps=True)
    assert len(res.steps) > 0

    for step in res.steps:
        # matrix_state must be present and 8x8
        assert step.matrix_state is not None
        assert len(step.matrix_state) == 8
        assert len(step.matrix_state[0]) == 8
        # Diagonal must always be 0
        for i in range(8):
            assert step.matrix_state[i][i] == 0.0

        # current_distances must be populated for all nodes
        assert len(step.current_distances) == 8
        assert step.current_distances[1] == 0.0  # Source to source distance is 0

    # Final step must have the optimal distance from 1 to 8
    final_step = res.steps[-1]
    assert final_step.current_distances[8] == 8.0

