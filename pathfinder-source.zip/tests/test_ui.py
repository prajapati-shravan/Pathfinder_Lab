"""
Integration tests for PathFinder Lab Qt GUI widgets and workflows.
"""

import pytest
from PySide6.QtWidgets import QApplication
from ui.main_window import MainWindow
from ui.step_viewer_dialog import StepViewerDialog
from ui.theory_dialog import TheoryDialog
from graph.generator import create_reference_8node_graph


@pytest.fixture(scope="session")
def qapp():
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    yield app


def test_main_window_startup(qapp):
    """Test MainWindow startup and default widgets."""
    window = MainWindow()
    assert window.windowTitle().startswith("PathFinder Lab")
    assert window.graph.node_count == 8
    assert window.graph.edge_count == 12
    window.close()


def test_ui_run_comparison_flow(qapp):
    """Test full comparison execution from the UI."""
    window = MainWindow()
    window.run_comparison(source=1, target=8)

    assert window.current_report is not None
    assert window.current_report.distances_agree is True

    # Check cards
    assert window.card_dijkstra.lbl_distance.text() == "8"
    assert window.card_floyd.lbl_distance.text() == "8"
    assert window.card_astar.lbl_distance.text() == "8"

    # Check comparison table
    assert window.comparison_table.table.item(0, 1).text() == "8"
    assert window.comparison_table.table.item(1, 1).text() == "8"
    assert window.comparison_table.table.item(2, 1).text() == "8"

    # Check fastest algorithm panel
    assert window.fastest_panel.lbl_winner.text() != "Pending Comparison"

    window.close()


def test_ui_graph_generation(qapp):
    """Test generating different sized graphs."""
    window = MainWindow()
    window.generate_new_graph(num_nodes=12)

    assert window.graph.node_count == 12
    assert window.graph.is_connected()
    assert window.sidebar.cmb_source.count() == 12
    assert window.sidebar.cmb_target.count() == 12

    window.run_comparison(source=1, target=12)
    assert window.current_report is not None
    assert window.current_report.distances_agree is True

    window.close()


def test_ui_resizing_and_scrolling(qapp):
    """Test window adaptation at various standard resolutions."""
    window = MainWindow()
    for w, h in [(1536, 1024), (1280, 800), (1024, 768)]:
        window.resize(w, h)
        assert window.width() == w
        assert window.height() == h
        # Ensure scroll area contains full content
        assert window.scroll_area.widget() is not None
    window.close()


def test_step_viewer_and_theory_dialogs(qapp):
    """Test step viewer and theory dialog initialization."""
    window = MainWindow()
    window.run_comparison(source=1, target=8)

    # Test Step Viewer for Dijkstra
    res_d = window.current_report.results["Dijkstra"]
    dlg_d = StepViewerDialog(res_d, window.graph, "#2563EB")
    assert len(res_d.steps) > 0
    dlg_d.show_step(1)
    assert dlg_d.current_step_idx == 1
    dlg_d.close()

    # Test Step Viewer for Floyd-Warshall
    res_fw = window.current_report.results["Floyd-Warshall"]
    dlg_fw = StepViewerDialog(res_fw, window.graph, "#7C3AED")
    dlg_fw.show_step(0)
    dlg_fw.close()

    # Test Theory Dialog
    theory_dlg = TheoryDialog()
    assert theory_dlg.windowTitle().startswith("Algorithm Theory")
    theory_dlg.close()

    window.close()
