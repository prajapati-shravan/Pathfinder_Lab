"""
Unit tests for graph data structures and generators.
"""

import pytest
from graph.generator import create_reference_8node_graph, generate_connected_graph


def test_reference_graph_properties():
    """Verify the reference 8-node graph properties match the specification."""
    g = create_reference_8node_graph()
    assert g.node_count == 8
    assert g.edge_count == 12
    assert g.density == 0.43
    assert g.is_connected()
    assert len(g.positions) == 8


@pytest.mark.parametrize("n", [2, 5, 8, 16, 30])
def test_generated_connected_graphs(n):
    """Verify random graphs are properly connected and populated."""
    g = generate_connected_graph(num_nodes=n, seed=42 + n)
    assert g.node_count == n
    assert g.is_connected()
    assert g.edge_count >= n - 1
    assert len(g.positions) == n
    for u, v, w in g.edges:
        assert w > 0
