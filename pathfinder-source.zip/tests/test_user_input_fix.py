"""
Automated UI and State Regression Tests for User Input Consistency.
Verifies Test A, Test B, Test C and consecutive target updates without restart.
"""

import pytest
from PySide6.QtWidgets import QApplication
from ui.main_window import MainWindow


@pytest.fixture(scope="session")
def qapp():
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    yield app


def test_user_input_test_a(qapp, capsys):
    """
    Test A:
    - Number of Nodes: 5
    - Source: 2
    - Target: 5
    Expected: Five graph nodes, source marker on Node 2, target marker on Node 5,
    and all algorithms calculate the route from 2 to 5.
    """
    window = MainWindow()

    # Set inputs
    window.sidebar.spin_nodes.setValue(5)
    idx_s = window.sidebar.cmb_source.findData(2)
    idx_t = window.sidebar.cmb_target.findData(5)
    window.sidebar.cmb_source.setCurrentIndex(idx_s)
    window.sidebar.cmb_target.setCurrentIndex(idx_t)

    # Click Generate Graph
    window.sidebar.btn_generate.click()

    # 1. Verify input controls
    assert window.sidebar.spin_nodes.value() == 5
    assert window.sidebar.get_source_node() == 2
    assert window.sidebar.get_target_node() == 5
    assert window.source_node == 2
    assert window.target_node == 5

    # 2. Verify generation log
    captured = capsys.readouterr()
    assert "[GENERATE_GRAPH] node_count=5 source=2 target=5" in captured.out

    # 3. Verify graph nodes and source/target markers
    assert window.graph.node_count == 5
    assert 2 in window.graph.nodes
    assert 5 in window.graph.nodes
    gv = window.graph_panel.graph_view
    assert gv.node_items[2].role == "source"
    assert gv.node_items[5].role == "target"

    # 4. Verify stale results cleared
    assert window.current_report is None
    assert window.card_dijkstra.lbl_distance.text() == "—"
    assert window.comparison_table.table.item(0, 1).text() == "—"

    # Click Run Comparison
    window.sidebar.btn_run.click()

    # 5. Verify algorithm execution logs
    captured2 = capsys.readouterr()
    assert "[RUN_COMPARISON] source=2 target=5" in captured2.out
    assert "[ALGO_EXEC] Dijkstra source=2 target=5" in captured2.out
    assert "[ALGO_EXEC] Floyd-Warshall source=2 target=5" in captured2.out
    assert "[ALGO_EXEC] A* source=2 target=5" in captured2.out

    # 6. Verify calculated paths connect 2 to 5 with valid edge weights
    report = window.current_report
    assert report is not None
    assert report.source == 2
    assert report.target == 5
    assert report.distances_agree is True

    for name in ["Dijkstra", "Floyd-Warshall", "A*"]:
        res = report.results[name]
        assert res.status == "Completed"
        assert res.has_path is True
        assert res.path[0] == 2
        assert res.path[-1] == 5
        path_ok, actual_dist, err = window.graph.validate_path(res.path, 2, 5)
        assert path_ok is True, f"{name} invalid path: {err}"
        assert abs(actual_dist - res.total_distance) < 1e-4

    window.close()


def test_user_input_test_b(qapp, capsys):
    """
    Test B:
    - Number of Nodes: 10
    - Source: 3
    - Target: 9
    Expected: Ten graph nodes, source marker on Node 3, target marker on Node 9,
    and all algorithms calculate the route from 3 to 9.
    """
    window = MainWindow()

    # Set inputs
    window.sidebar.spin_nodes.setValue(10)
    idx_s = window.sidebar.cmb_source.findData(3)
    idx_t = window.sidebar.cmb_target.findData(9)
    window.sidebar.cmb_source.setCurrentIndex(idx_s)
    window.sidebar.cmb_target.setCurrentIndex(idx_t)

    # Click Generate Graph
    window.sidebar.btn_generate.click()

    # Verify input controls and authoritative state
    assert window.sidebar.spin_nodes.value() == 10
    assert window.sidebar.get_source_node() == 3
    assert window.sidebar.get_target_node() == 9
    assert window.source_node == 3
    assert window.target_node == 9

    # Verify log
    captured = capsys.readouterr()
    assert "[GENERATE_GRAPH] node_count=10 source=3 target=9" in captured.out

    # Verify markers
    assert window.graph.node_count == 10
    gv = window.graph_panel.graph_view
    assert gv.node_items[3].role == "source"
    assert gv.node_items[9].role == "target"

    # Click Run Comparison
    window.sidebar.btn_run.click()

    captured2 = capsys.readouterr()
    assert "[RUN_COMPARISON] source=3 target=9" in captured2.out

    report = window.current_report
    assert report.source == 3
    assert report.target == 9
    assert report.distances_agree is True

    for name in ["Dijkstra", "Floyd-Warshall", "A*"]:
        res = report.results[name]
        assert res.has_path is True
        assert res.path[0] == 3
        assert res.path[-1] == 9
        path_ok, actual_dist, err = window.graph.validate_path(res.path, 3, 9)
        assert path_ok is True
        assert abs(actual_dist - res.total_distance) < 1e-4

    window.close()


def test_user_input_test_c(qapp, capsys):
    """
    Test C:
    - Number of Nodes: 6
    - Source: 6
    - Target: 1
    Expected: Six graph nodes, source marker on Node 6, target marker on Node 1,
    and all algorithms calculate the route from 6 to 1.
    """
    window = MainWindow()

    # Set inputs
    window.sidebar.spin_nodes.setValue(6)
    idx_s = window.sidebar.cmb_source.findData(6)
    idx_t = window.sidebar.cmb_target.findData(1)
    window.sidebar.cmb_source.setCurrentIndex(idx_s)
    window.sidebar.cmb_target.setCurrentIndex(idx_t)

    # Click Generate Graph
    window.sidebar.btn_generate.click()

    assert window.sidebar.spin_nodes.value() == 6
    assert window.sidebar.get_source_node() == 6
    assert window.sidebar.get_target_node() == 1
    assert window.source_node == 6
    assert window.target_node == 1

    captured = capsys.readouterr()
    assert "[GENERATE_GRAPH] node_count=6 source=6 target=1" in captured.out

    # Verify markers
    assert window.graph.node_count == 6
    gv = window.graph_panel.graph_view
    assert gv.node_items[6].role == "source"
    assert gv.node_items[1].role == "target"

    # Click Run Comparison
    window.sidebar.btn_run.click()

    captured2 = capsys.readouterr()
    assert "[RUN_COMPARISON] source=6 target=1" in captured2.out

    report = window.current_report
    assert report.source == 6
    assert report.target == 1
    assert report.distances_agree is True

    for name in ["Dijkstra", "Floyd-Warshall", "A*"]:
        res = report.results[name]
        assert res.has_path is True
        assert res.path[0] == 6
        assert res.path[-1] == 1
        path_ok, actual_dist, err = window.graph.validate_path(res.path, 6, 1)
        assert path_ok is True
        assert abs(actual_dist - res.total_distance) < 1e-4

    window.close()


def test_change_target_several_times_without_restart(qapp, capsys):
    """
    Test changing only the target dropdown several times without restarting the application:
    - Verify target marker moves immediately.
    - Verify previous shortest-path highlight is cleared.
    - Verify run_comparison calculates the new route.
    """
    window = MainWindow()

    # Start with 8-node graph, source 1
    window.generate_new_graph(num_nodes=8, source=1, target=8)
    window.run_comparison(source=1, target=8)
    assert window.current_report.target == 8

    # Change 1: Target to 4
    idx_4 = window.sidebar.cmb_target.findData(4)
    window.sidebar.cmb_target.setCurrentIndex(idx_4)
    assert window.target_node == 4
    assert window.graph_panel.graph_view.node_items[4].role == "target"
    # Old path 1->8 cleared
    assert window.graph_panel.graph_view.shortest_path == []
    # Run comparison
    window.sidebar.btn_run.click()
    assert window.current_report.target == 4
    for res in window.current_report.results.values():
        assert res.path[-1] == 4

    # Change 2: Target to 7
    idx_7 = window.sidebar.cmb_target.findData(7)
    window.sidebar.cmb_target.setCurrentIndex(idx_7)
    assert window.target_node == 7
    assert window.graph_panel.graph_view.node_items[7].role == "target"
    assert window.graph_panel.graph_view.shortest_path == []
    window.sidebar.btn_run.click()
    assert window.current_report.target == 7
    for res in window.current_report.results.values():
        assert res.path[-1] == 7

    # Change 3: Target to 2
    idx_2 = window.sidebar.cmb_target.findData(2)
    window.sidebar.cmb_target.setCurrentIndex(idx_2)
    assert window.target_node == 2
    assert window.graph_panel.graph_view.node_items[2].role == "target"
    assert window.graph_panel.graph_view.shortest_path == []
    window.sidebar.btn_run.click()
    assert window.current_report.target == 2
    for res in window.current_report.results.values():
        assert res.path[-1] == 2

    window.close()
