"""
Regression Test Suite for PathFinder Lab Comparison Consistency.
Covers all 10 required test cases specified in the bug fix prompt.
"""

import pytest
from graph.graph_data import GraphData
from graph.generator import create_reference_8node_graph, generate_connected_graph
from benchmark.benchmark_runner import BenchmarkRunner
from algorithms.dijkstra import dijkstra_shortest_path
from algorithms.floyd_warshall import floyd_warshall_shortest_path
from algorithms.astar import astar_shortest_path


def test_1_2_3_repeated_comparison_consistency_and_fingerprint():
    """
    Cases 1, 2, 3:
    1. Run Comparison five times on an unchanged graph.
    2. Confirm that all successful algorithms return the same optimal distance on every run.
    3. Confirm that the graph fingerprint never changes.
    """
    g = create_reference_8node_graph()
    initial_fp = g.fingerprint
    runner = BenchmarkRunner(trials=15, warmup_runs=2)

    expected_distance = 8.0

    for run_idx in range(5):
        # Fingerprint before comparison
        assert g.fingerprint == initial_fp, f"Fingerprint changed before run {run_idx+1}"

        report = runner.run_benchmark(g, source=1, target=8, record_visual_steps=True)

        # Fingerprint after comparison
        assert g.fingerprint == initial_fp, f"Fingerprint changed after run {run_idx+1}"
        assert report.graph_fingerprint == initial_fp

        # All algorithms must agree on the optimal distance
        assert report.distances_agree is True
        for algo_name in ["Dijkstra", "Floyd-Warshall", "A*"]:
            res = report.results[algo_name]
            assert res.status == "Completed"
            assert res.has_path is True
            assert round(res.total_distance, 4) == expected_distance, (
                f"Run {run_idx+1} {algo_name} distance {res.total_distance} != {expected_distance}"
            )


def test_4_reconstructed_paths_have_valid_edges_and_reported_distance():
    """
    Case 4: Confirm that reconstructed paths have valid edges and the reported total distance.
    """
    for seed in [10, 20, 30]:
        g = generate_connected_graph(num_nodes=10, seed=seed)
        source, target = 1, 10
        runner = BenchmarkRunner(trials=10, warmup_runs=2)
        report = runner.run_benchmark(g, source, target)

        assert report.distances_agree is True

        for algo_name in ["Dijkstra", "Floyd-Warshall", "A*"]:
            res = report.results[algo_name]
            assert res.has_path is True

            # Validate path endpoints and connectivity
            is_valid, actual_dist, err = g.validate_path(res.path, source, target)
            assert is_valid is True, f"{algo_name} returned invalid path: {err}"
            assert abs(actual_dist - res.total_distance) < 1e-4, (
                f"{algo_name} reported distance {res.total_distance} != actual edge sum {actual_dist}"
            )


def test_5_disconnected_graphs():
    """
    Case 5: Test disconnected graphs (unreachable target).
    """
    g = GraphData(is_synthetic=True)
    # Component 1
    g.add_node(1, (100.0, 100.0))
    g.add_node(2, (200.0, 100.0))
    g.add_edge(1, 2, 5.0)

    # Component 2 (disconnected from Component 1)
    g.add_node(3, (400.0, 400.0))
    g.add_node(4, (500.0, 400.0))
    g.add_edge(3, 4, 3.0)

    runner = BenchmarkRunner(trials=10, warmup_runs=2)
    report = runner.run_benchmark(g, source=1, target=4)

    assert report.distances_agree is True
    for algo_name in ["Dijkstra", "Floyd-Warshall", "A*"]:
        res = report.results[algo_name]
        assert res.status == "No Path"
        assert res.has_path is False
        assert res.total_distance == float("inf")
        assert res.path == []

    assert "unreachable" in report.explanation.lower() or "no path" in report.warning.lower()


def test_6_source_equal_to_target():
    """
    Case 6: Test source equal to target.
    """
    g = create_reference_8node_graph()
    runner = BenchmarkRunner(trials=10, warmup_runs=2)

    for node in [1, 4, 8]:
        report = runner.run_benchmark(g, source=node, target=node)
        assert report.distances_agree is True

        for algo_name in ["Dijkstra", "Floyd-Warshall", "A*"]:
            res = report.results[algo_name]
            assert res.status == "Completed"
            assert res.total_distance == 0.0
            assert res.path == [node]


def test_7_multiple_equally_short_paths():
    """
    Case 7: Test graphs with multiple equally short paths.
    Validates that any valid optimal path is accepted without requiring identical node sequences.
    """
    g = GraphData(is_synthetic=True)
    # Path 1: 1 -> 2 -> 4 (w = 2 + 3 = 5)
    # Path 2: 1 -> 3 -> 4 (w = 1 + 4 = 5)
    g.add_node(1, (100.0, 200.0))
    g.add_node(2, (200.0, 100.0))
    g.add_node(3, (200.0, 300.0))
    g.add_node(4, (300.0, 200.0))

    g.add_edge(1, 2, 2.0)
    g.add_edge(2, 4, 3.0)
    g.add_edge(1, 3, 1.0)
    g.add_edge(3, 4, 4.0)

    runner = BenchmarkRunner(trials=10, warmup_runs=2)
    report = runner.run_benchmark(g, source=1, target=4)

    assert report.distances_agree is True

    for algo_name in ["Dijkstra", "Floyd-Warshall", "A*"]:
        res = report.results[algo_name]
        assert res.total_distance == 5.0
        # Valid path from 1 to 4
        is_valid, actual_dist, err = g.validate_path(res.path, 1, 4)
        assert is_valid is True, f"{algo_name} path invalid: {err}"
        assert actual_dist == 5.0
        assert res.path in [[1, 2, 4], [1, 3, 4]]


def test_8_different_positive_edge_weights():
    """
    Case 8: Test different positive edge weights (floating-point decimals and wide ranges).
    """
    g = GraphData(is_synthetic=True)
    g.add_node(1, (100.0, 100.0))
    g.add_node(2, (250.0, 120.0))
    g.add_node(3, (400.0, 150.0))
    g.add_node(4, (550.0, 180.0))

    # Fractional and varied positive weights
    g.add_edge(1, 2, 0.75)
    g.add_edge(2, 3, 12.333)
    g.add_edge(3, 4, 4.25)
    g.add_edge(1, 3, 10.5)  # Alternative path 1 -> 3 -> 4 = 14.75 vs 1 -> 2 -> 3 -> 4 = 17.333

    runner = BenchmarkRunner(trials=10, warmup_runs=2)
    report = runner.run_benchmark(g, source=1, target=4)

    assert report.distances_agree is True
    expected = 14.75  # 1 -> 3 -> 4
    for algo_name in ["Dijkstra", "Floyd-Warshall", "A*"]:
        res = report.results[algo_name]
        assert pytest.approx(res.total_distance, rel=1e-5) == expected
        assert res.path == [1, 3, 4]


def test_9_generate_new_graph_updates_comparison():
    """
    Case 9: Generate a new graph and verify that the comparison updates correctly.
    """
    # Graph 1
    g1 = create_reference_8node_graph()
    fp1 = g1.fingerprint
    runner = BenchmarkRunner(trials=10, warmup_runs=2)
    rep1 = runner.run_benchmark(g1, source=1, target=8)
    assert rep1.graph_fingerprint == fp1
    assert rep1.results["Dijkstra"].total_distance == 8.0

    # Graph 2 (different structure)
    g2 = generate_connected_graph(num_nodes=12, seed=777)
    fp2 = g2.fingerprint
    assert fp2 != fp1, "New graph should have a distinct fingerprint"

    rep2 = runner.run_benchmark(g2, source=1, target=12)
    assert rep2.graph_fingerprint == fp2
    assert rep2.graph_node_count == 12
    assert rep2.distances_agree is True
    assert rep2.results["Dijkstra"].has_path is True
    assert rep2.results["Floyd-Warshall"].has_path is True
    assert rep2.results["A*"].has_path is True
    # All 3 algorithms must match distance on new graph
    d2 = rep2.results["Dijkstra"].total_distance
    assert pytest.approx(rep2.results["Floyd-Warshall"].total_distance, rel=1e-5) == d2
    assert pytest.approx(rep2.results["A*"].total_distance, rel=1e-5) == d2


def test_10_execution_times_may_vary_without_false_correctness_errors():
    """
    Case 10: Confirm that execution times may vary without causing false correctness errors.
    Even when times fluctuate across multiple runs, correctness checks remain 100% valid.
    """
    g = create_reference_8node_graph()
    runner = BenchmarkRunner(trials=20, warmup_runs=3)

    measured_times = []
    for _ in range(3):
        report = runner.run_benchmark(g, source=1, target=8)
        assert report.distances_agree is True
        assert report.warning is None
        assert all("PASSED" in status for status in report.validation_status.values())
        measured_times.append(report.median_times_ms["Dijkstra"])

    # Distances remain optimal regardless of minor timing jitter
    assert all(t > 0 for t in measured_times)
