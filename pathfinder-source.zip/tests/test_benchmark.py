"""
Unit tests for the benchmarking engine.
"""

from benchmark.benchmark_runner import BenchmarkRunner
from graph.generator import create_reference_8node_graph


def test_benchmark_runner():
    """Verify multi-trial benchmark execution, results consistency, and report structure."""
    g = create_reference_8node_graph()
    runner = BenchmarkRunner(trials=15, warmup_runs=2)
    report = runner.run_benchmark(g, source=1, target=8)

    assert report.trials_count == 15
    assert report.distances_agree is True
    assert "Dijkstra" in report.results
    assert "Floyd-Warshall" in report.results
    assert "A*" in report.results

    for algo in ["Dijkstra", "Floyd-Warshall", "A*"]:
        assert report.median_times_ms[algo] > 0
        assert report.results[algo].total_distance == 8.0

    assert report.winner_name is not None
    assert len(report.explanation) > 0
