"""
Capture dialog screenshots for verification.
"""

import sys
import os
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer
from ui.main_window import MainWindow
from ui.step_viewer_dialog import StepViewerDialog
from ui.theory_dialog import TheoryDialog
from graph.generator import create_reference_8node_graph
from benchmark.benchmark_runner import BenchmarkRunner

from ui.theme import GLOBAL_STYLESHEET

def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(GLOBAL_STYLESHEET)
    
    g = create_reference_8node_graph()
    runner = BenchmarkRunner(trials=10, warmup_runs=1)
    report = runner.run_benchmark(g, 1, 8, record_visual_steps=True)
    
    # 1. Dijkstra Step Viewer
    d_res = report.results["Dijkstra"]
    d_dlg = StepViewerDialog(d_res, g, "#2563EB")
    d_dlg.resize(1000, 680)
    d_dlg.show()
    d_dlg.show_step(2)
    app.processEvents()
    d_dlg.grab().save(r"C:\Users\praja\.gemini\antigravity-ide\brain\7546c457-4f3d-4440-89a9-ade65e6ea7eb\step_viewer_dijkstra.png")
    d_dlg.close()

    # 2. Floyd-Warshall Step Viewer (Matrix tab)
    fw_res = report.results["Floyd-Warshall"]
    fw_dlg = StepViewerDialog(fw_res, g, "#7C3AED")
    fw_dlg.resize(1000, 680)
    fw_dlg.show()
    fw_dlg.show_step(3)
    fw_dlg.view_stack.setCurrentIndex(1)  # Matrix view
    app.processEvents()
    fw_dlg.grab().save(r"C:\Users\praja\.gemini\antigravity-ide\brain\7546c457-4f3d-4440-89a9-ade65e6ea7eb\step_viewer_floyd_matrix.png")
    fw_dlg.close()

    # 3. Theory Dialog
    t_dlg = TheoryDialog()
    t_dlg.resize(840, 600)
    t_dlg.show()
    app.processEvents()
    t_dlg.grab().save(r"C:\Users\praja\.gemini\antigravity-ide\brain\7546c457-4f3d-4440-89a9-ade65e6ea7eb\theory_dialog.png")
    t_dlg.close()

    print("ALL_DIALOGS_CAPTURED")
    app.quit()

if __name__ == "__main__":
    main()
