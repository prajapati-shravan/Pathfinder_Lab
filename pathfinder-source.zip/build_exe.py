"""
PyInstaller packaging script for PathFinder Lab.
Builds a standalone Windows executable.
"""

import sys
import subprocess
import os

def build():
    print("Building PathFinder Lab Standalone Executable with PyInstaller...")
    
    cmd = [
        sys.executable,
        "-m", "PyInstaller",
        "-y",
        "--name=PathFinderLab",
        "--onedir",
        "--windowed",
        "--clean",
        "--add-data=ui;ui",
        "--add-data=graph;graph",
        "--add-data=algorithms;algorithms",
        "--add-data=benchmark;benchmark",
        "main.py"
    ]
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    print("Return code:", result.returncode)
    print("STDOUT:", result.stdout[-500:] if result.stdout else "")
    if result.returncode == 0:
        exe_path = os.path.abspath("dist/PathFinderLab/PathFinderLab.exe")
        print(f"\nSUCCESS! Standalone executable created at:\n{exe_path}")
    else:
        print("STDERR:", result.stderr[-500:] if result.stderr else "")

if __name__ == "__main__":
    build()
