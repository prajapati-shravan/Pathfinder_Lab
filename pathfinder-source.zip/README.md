# PathFinder Lab — Shortest Path Algorithm Performance Analyzer

A professional, high-performance desktop application for analyzing, visualizing, and benchmarking classic shortest path graph algorithms: **Dijkstra's Algorithm**, **Floyd–Warshall Algorithm**, and **A* (A-Star) Search**.

Built strictly as a native desktop application in Python using **PySide6 (Qt for Python)**, **NetworkX**, and high-resolution system timers (`time.perf_counter_ns`).

![PathFinder Lab UI](assets/pathfinder_app_screenshot.png)

---

## Key Features

- **Strict White/Light Theme**: Harmonious, high-contrast palette (`#F5F8FC` window, `#FFFFFF` panels, `#DCE5F0` borders, `#10234D` typography, `#F59E0B` golden shortest path) with zero dark mode switches.
- **Interactive 2D Graph Canvas**:
  - Live draggable nodes with real-time edge and weight updates.
  - Controls for Zoom In, Zoom Out, Fit to Screen, Reset Layout, and Show/Hide Weights.
  - Floating canvas legend identifying Source, Target, Normal nodes, Shortest Path, and Explored/Relaxed edges.
  - Synthetic test graph generation with guaranteed connectivity for $N \in [2, 100]$.
- **Three Algorithm Cards**:
  - **Dijkstra's Algorithm** (Blue Accent `#2563EB`): Adjacency list with binary min-heap priority queue ($O((V + E) \log V)$).
  - **Floyd–Warshall Algorithm** (Purple Accent `#7C3AED`): Triple-loop dynamic programming ($O(V^3)$) with all-pairs distance matrix.
  - **A* Algorithm** (Emerald Accent `#059669`): Heuristic best-first search with provably admissible Euclidean scale factor.
  - Embedded mini-graph previews displaying algorithm-specific explored edges in accent colors.
- **True High-Resolution Benchmarking**:
  - Completely isolates pure algorithmic execution from UI rendering and animation.
  - Runs warmup iterations and 50 isolated trials using monotonic nanosecond clocks.
  - Reports median runtimes, statistical time savings, and honest noise-floor thresholds.
  - Validates that all three algorithms produce matching optimal path distances before declaring an empirical winner.
- **Step-by-Step Execution Trace Viewer**:
  - Step navigation: Previous Step, Next Step, Play, Pause, Restart, scrubber slider, and playback speed control.
  - Visualizes active vertex ring, relaxed edges, visited sets, and shortest paths.
  - **Intermediate Distance Matrix Viewer** for Floyd-Warshall displaying the $V \times V$ matrix with $\infty$ for unreached pairs.
- **Educational Algorithm Theory Dialog**:
  - Comparative Big-O time and space complexity table.
  - Explanations of theoretical complexity vs. real-world execution metrics.

---

## Directory Structure

```text
pathfinder/
├── algorithms/
│   ├── __init__.py
│   ├── base.py              # AlgorithmResult and StepTrace data models
│   ├── dijkstra.py          # Min-heap Dijkstra with path reconstruction
│   ├── floyd_warshall.py    # All-pairs DP with next-hop matrix
│   └── astar.py             # Admissible heuristic A* with priority queue
├── graph/
│   ├── __init__.py
│   ├── graph_data.py        # Graph model, adjacency lists, and connectivity
│   ├── generator.py         # 8-node reference preset & connected random graphs
│   └── layout.py            # Force-directed spring layout positioning
├── benchmark/
│   ├── __init__.py
│   └── benchmark_runner.py  # Multi-trial timer, warmup runs, and statistical validation
├── ui/
│   ├── __init__.py
│   ├── theme.py             # Design tokens, color hexes, and global QSS
│   ├── main_window.py       # Main window uniting sidebar, canvas, cards, and tables
│   ├── header_bar.py        # Top bar with logo, stat badges, and primary actions
│   ├── sidebar.py           # Fixed-width input sidebar (230px)
│   ├── graph_view.py        # Interactive QGraphicsView canvas with draggable nodes
│   ├── mini_graph_view.py   # Compact mini-graph preview widget
│   ├── algorithm_card.py    # Triple algorithm cards
│   ├── comparison_table.py  # Bottom comparison metrics table
│   ├── fastest_panel.py     # Trophy card displaying measured winner
│   ├── step_viewer_dialog.py# Interactive step playback and matrix inspector
│   └── theory_dialog.py     # Theory & Big-O complexity modal dialog
├── tests/
│   ├── test_algorithms.py   # Unit tests for algorithm correctness & path reconstruction
│   ├── test_graph.py        # Unit tests for graph properties and generators
│   ├── test_benchmark.py    # Unit tests for benchmark statistical outputs
│   └── test_ui.py           # Integration tests for UI workflows and resizing
├── requirements.txt         # Project dependencies
├── build_exe.py             # Standalone Windows executable build script
├── main.py                  # Desktop application entry point
└── README.md                # Documentation and usage guide
```

---

## Installation & Setup

### 1. Prerequisites
- Python 3.11 or newer (Python 3.13 tested)
- Windows 10/11 (or macOS / Linux)

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

---

## Launching the Application

Run the desktop application:
```bash
python main.py
```

The application opens at 1536 × 1024 pixels with the default 8-node reference graph loaded, source node 1, target node 8, and initial benchmark results displayed.

---

## Running the Automated Test Suite

To run all 19 unit and integration tests:
```bash
python -m pytest tests -v
```

All tests verify:
- Dijkstra, Floyd-Warshall, and A* yield identical optimal shortest path distances.
- Floyd-Warshall and Dijkstra correctly reconstruct paths.
- Connected graph generator produces connected graphs with positive weights.
- Multi-trial benchmark runner executes and verifies consistency.
- UI elements, step viewer, and theory dialogs initialize without errors.
- Responsive layout resizes down to 1024 × 768 and 1280 × 800 without clipping.

---

## Building a Standalone Windows Executable

To package PathFinder Lab into a standalone Windows application folder containing `PathFinderLab.exe`:

```bash
python build_exe.py
```

The resulting executable will be located in:
```text
dist/PathFinderLab/PathFinderLab.exe
```

Double-click `PathFinderLab.exe` to run the software without needing Python installed on the host machine.
