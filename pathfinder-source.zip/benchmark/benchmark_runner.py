"""
High-resolution benchmarking runner for shortest path algorithms.
Runs multi-trial measurements using time.perf_counter_ns with warmups.
Provides comprehensive correctness validation, immutable graph fingerprint checks,
and diagnostic logging.
"""

import time
import logging
import statistics
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from algorithms.base import AlgorithmResult
from algorithms.dijkstra import dijkstra_shortest_path
from algorithms.floyd_warshall import floyd_warshall_shortest_path
from algorithms.astar import astar_shortest_path
from graph.graph_data import GraphData

logger = logging.getLogger("pathfinder.diagnostic")
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "[%(asctime)s] [DIAGNOSTIC] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)


@dataclass
class BenchmarkReport:
    """Consolidated benchmark results across all algorithms."""
    run_id: str = ""
    graph_fingerprint: str = ""
    graph_node_count: int = 0
    graph_edge_count: int = 0
    source: int = 1
    target: int = 8
    results: Dict[str, AlgorithmResult] = field(default_factory=dict)
    trials_count: int = 50
    median_times_ms: Dict[str, float] = field(default_factory=dict)
    min_times_ms: Dict[str, float] = field(default_factory=dict)
    max_times_ms: Dict[str, float] = field(default_factory=dict)
    all_trials_ms: Dict[str, List[float]] = field(default_factory=dict)
    validation_status: Dict[str, str] = field(default_factory=dict)
    winner_name: Optional[str] = None
    winner_time_ms: float = 0.0
    slowest_name: Optional[str] = None
    slowest_time_ms: float = 0.0
    time_saved_ms: float = 0.0
    time_saved_pct: float = 0.0
    explanation: str = ""
    distances_agree: bool = True
    is_noise_level: bool = False
    warning: Optional[str] = None


class BenchmarkRunner:
    """Executes high-precision isolated benchmarking trials."""

    def __init__(self, trials: int = 50, warmup_runs: int = 5):
        self.trials = max(5, trials)
        self.warmup_runs = max(1, warmup_runs)
        self._run_counter: int = 0

    def run_benchmark(
        self,
        graph: GraphData,
        source: int,
        target: int,
        record_visual_steps: bool = True
    ) -> BenchmarkReport:
        """
        Runs benchmarking across Dijkstra, Floyd-Warshall, and A*.
        Measures pure algorithm execution time without UI or step recording overhead.
        Validates correctness and immutability before and after execution.
        """
        self._run_counter += 1
        run_id = f"run-{self._run_counter:04d}-{uuid.uuid4().hex[:6]}"
        fp_initial = graph.fingerprint

        report = BenchmarkReport(
            run_id=run_id,
            graph_fingerprint=fp_initial,
            graph_node_count=graph.node_count,
            graph_edge_count=graph.edge_count,
            source=source,
            target=target,
            trials_count=self.trials
        )

        logger.info(
            f"=== START BENCHMARK {run_id} | Fingerprint: {fp_initial} | "
            f"Nodes: {graph.node_count}, Edges: {graph.edge_count} | Source: {source} -> Target: {target} ==="
        )

        # 1. Warm-up runs to prime JIT/Python caches and memory allocator
        for _ in range(self.warmup_runs):
            dijkstra_shortest_path(graph, source, target, record_steps=False)
            floyd_warshall_shortest_path(graph, source, target, record_steps=False)
            astar_shortest_path(graph, source, target, record_steps=False)

        # Algorithms to benchmark
        algos = {
            "Dijkstra": lambda: dijkstra_shortest_path(graph, source, target, record_steps=False),
            "Floyd-Warshall": lambda: floyd_warshall_shortest_path(graph, source, target, record_steps=False),
            "A*": lambda: astar_shortest_path(graph, source, target, record_steps=False)
        }

        # Diagnostic logging for algorithms and inputs (TASK 6)
        print(f"[ALGO_EXEC] Dijkstra source={source} target={target}", flush=True)
        print(f"[ALGO_EXEC] Floyd-Warshall source={source} target={target}", flush=True)
        print(f"[ALGO_EXEC] A* source={source} target={target}", flush=True)
        logger.info(f"[ALGO_EXEC] Dijkstra source={source} target={target}")
        logger.info(f"[ALGO_EXEC] Floyd-Warshall source={source} target={target}")
        logger.info(f"[ALGO_EXEC] A* source={source} target={target}")

        # 2. Benchmark trials: pure monotonic clock measurement
        for name, algo_func in algos.items():
            trial_times = []
            for _ in range(self.trials):
                t0 = time.perf_counter_ns()
                algo_func()
                t1 = time.perf_counter_ns()
                duration_ms = (t1 - t0) / 1_000_000.0  # Convert ns to ms
                trial_times.append(duration_ms)

            report.all_trials_ms[name] = trial_times
            med = statistics.median(trial_times)
            # Display sub-millisecond times with sufficient precision
            if med < 0.001:
                med = max(med, 0.001)
            report.median_times_ms[name] = round(med, 4)
            report.min_times_ms[name] = round(min(trial_times), 4)
            report.max_times_ms[name] = round(max(trial_times), 4)

        # Verify graph immutability during timed trials
        fp_after_timing = graph.fingerprint
        if fp_after_timing != fp_initial:
            raise RuntimeError(
                f"CRITICAL: Graph mutated during benchmarking! Before: {fp_initial}, After: {fp_after_timing}"
            )

        # 3. Visual run with step tracking (separate from timing)
        d_res = dijkstra_shortest_path(graph, source, target, record_steps=record_visual_steps)
        d_res.execution_time_ms = report.median_times_ms["Dijkstra"]
        report.results["Dijkstra"] = d_res

        fw_res = floyd_warshall_shortest_path(graph, source, target, record_steps=record_visual_steps)
        fw_res.execution_time_ms = report.median_times_ms["Floyd-Warshall"]
        report.results["Floyd-Warshall"] = fw_res

        a_res = astar_shortest_path(graph, source, target, record_steps=record_visual_steps)
        a_res.execution_time_ms = report.median_times_ms["A*"]
        report.results["A*"] = a_res

        # Verify graph immutability after step recording
        fp_after_steps = graph.fingerprint
        if fp_after_steps != fp_initial:
            raise RuntimeError(
                f"CRITICAL: Graph mutated during step recording! Before: {fp_initial}, After: {fp_after_steps}"
            )

        # 4. Correctness validation: calculate and validate each algorithm
        successful_algos = []
        valid_distances = []

        for name, res in report.results.items():
            is_valid = True
            val_notes = []

            if res.status == "Completed":
                if source == target:
                    if res.path != [source] or res.total_distance != 0.0:
                        is_valid = False
                        val_notes.append("Expected path [source] and distance 0.0 for source==target")
                else:
                    path_ok, actual_weight, err_msg = graph.validate_path(res.path, source, target)
                    if not path_ok:
                        is_valid = False
                        val_notes.append(f"Invalid path structure: {err_msg}")
                    elif abs(actual_weight - res.total_distance) > 1e-4:
                        is_valid = False
                        val_notes.append(
                            f"Distance mismatch: reported {res.total_distance:.4f} != actual edge sum {actual_weight:.4f}"
                        )

                if is_valid:
                    successful_algos.append(name)
                    valid_distances.append(round(res.total_distance, 4))
                    report.validation_status[name] = "PASSED (Valid optimal path)"
                else:
                    report.validation_status[name] = f"FAILED ({'; '.join(val_notes)})"
            elif res.status == "No Path":
                report.validation_status[name] = "PASSED (Confirmed unreachable)"
            else:
                report.validation_status[name] = f"FAILED (Status: {res.status})"

            # Diagnostic logging per algorithm
            logger.info(
                f"[{run_id}] Algorithm: {name:<14} | Dist: {res.total_distance:.2f} | "
                f"Path: {res.path_string} | MedianTime: {report.median_times_ms.get(name, 0.0):.4f} ms "
                f"({self.trials} trials) | Visited: {res.nodes_visited} | Examined: {res.edges_examined} | "
                f"Validation: {report.validation_status[name]}"
            )

        # 5. Check if all successful algorithms found the exact same optimal distance
        if len(valid_distances) > 0:
            first_dist = valid_distances[0]
            all_match = all(d == first_dist for d in valid_distances)
            report.distances_agree = all_match
            if not all_match:
                report.warning = (
                    f"Correctness Alert: Differing path distances detected: {dict(zip(successful_algos, valid_distances))}!"
                )
                report.explanation = "Winner selection disabled due to distance mismatch."
                logger.warning(f"[{run_id}] {report.warning}")
                return report
        else:
            # All algorithms found no path (target unreachable)
            report.distances_agree = True
            report.warning = "No path exists between selected source and target."
            report.explanation = "All algorithms confirmed the target is unreachable."
            logger.info(f"[{run_id}] All algorithms confirmed target unreachable.")
            return report

        # 6. Correct fastest-algorithm selection among valid successful algorithms
        # Compare measured median times ONLY after all successful algorithms pass correctness checks.
        valid_times = [(name, report.median_times_ms[name]) for name in successful_algos]
        sorted_times = sorted(valid_times, key=lambda x: x[1])

        if not sorted_times:
            report.explanation = "No algorithm completed successfully."
            return report

        fastest_name, fastest_time = sorted_times[0]
        slowest_name, slowest_time = sorted_times[-1]

        report.winner_time_ms = fastest_time
        report.slowest_name = slowest_name
        report.slowest_time_ms = slowest_time

        # Check margin between 1st place and 2nd place (runner-up)
        if len(sorted_times) > 1:
            runner_up_name, runner_up_time = sorted_times[1]
            margin_runner_up = runner_up_time - fastest_time
        else:
            runner_up_name, runner_up_time = fastest_name, fastest_time
            margin_runner_up = 0.0

        diff_slowest = slowest_time - fastest_time
        report.time_saved_ms = round(diff_slowest, 4)
        if slowest_time > 0:
            report.time_saved_pct = round((diff_slowest / slowest_time) * 100.0, 1)

        # Distinguish real algorithmic advantage from sub-millisecond OS noise:
        # If the gap between 1st and 2nd place is below reliable timer noise (<0.005 ms / <5%),
        # or if source == target (trivial lookup), declare no reliable performance winner.
        is_sub_resolution = (
            source == target or
            (margin_runner_up < 0.005 and (fastest_time < 0.05 or (runner_up_time > 0 and (margin_runner_up / runner_up_time) < 0.05)))
        )

        if is_sub_resolution:
            report.is_noise_level = True
            report.winner_name = "No reliable performance winner at this test size."
            report.explanation = (
                f"Timing difference between top algorithms ({fastest_name}: {fastest_time:.3f} ms vs "
                f"{runner_up_name}: {runner_up_time:.3f} ms, gap: {margin_runner_up:.4f} ms) "
                f"is within system timer resolution limits (<0.005 ms / <5%). "
                f"No reliable performance winner at this test size."
            )
            logger.info(f"[{run_id}] Result: No reliable performance winner (Noise level).")
        else:
            report.winner_name = f"{fastest_name} Algorithm" if "Algorithm" not in fastest_name else fastest_name
            if "A*" in fastest_name:
                report.explanation = (
                    f"A* achieved the lowest median runtime ({fastest_time:.3f} ms), "
                    f"saving {report.time_saved_ms:.3f} ms ({report.time_saved_pct}%) vs {slowest_name} "
                    f"due to goal-directed heuristic search pruning."
                )
            elif "Dijkstra" in fastest_name:
                report.explanation = (
                    f"Dijkstra achieved the lowest median runtime ({fastest_time:.3f} ms), "
                    f"saving {report.time_saved_ms:.3f} ms ({report.time_saved_pct}%) vs {slowest_name} "
                    f"by greedily exploring minimal frontier nodes with low heap overhead."
                )
            else:
                report.explanation = (
                    f"{fastest_name} was fastest ({fastest_time:.3f} ms) across {self.trials} trials."
                )
            logger.info(f"[{run_id}] Result Winner: {report.winner_name} ({fastest_time:.4f} ms)")

        return report
