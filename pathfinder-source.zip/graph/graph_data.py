"""
Graph data structures and representation.
"""

import hashlib
from typing import List, Tuple, Dict, Set, Optional


class GraphData:
    """
    Undirected weighted graph representation with 2D positions and metadata.
    """
    def __init__(self, is_synthetic: bool = True):
        self.nodes: Set[int] = set()
        self.edges: List[Tuple[int, int, float]] = []  # (u, v, weight)
        self.positions: Dict[int, Tuple[float, float]] = {}  # node -> (x, y)
        self._adjacency: Dict[int, List[Tuple[int, float]]] = {}
        self.is_synthetic: bool = is_synthetic
        self.name: str = "Synthetic Test Graph"
        self.version: int = 1

    def add_node(self, node: int, pos: Optional[Tuple[float, float]] = None) -> None:
        self.nodes.add(node)
        if node not in self._adjacency:
            self._adjacency[node] = []
        if pos is not None:
            self.positions[node] = pos

    def add_edge(self, u: int, v: int, weight: float) -> None:
        if u not in self.nodes:
            self.add_node(u)
        if v not in self.nodes:
            self.add_node(v)

        # Remove existing edge between u and v if present
        self.edges = [e for e in self.edges if not ((e[0] == u and e[1] == v) or (e[0] == v and e[1] == u))]
        self._adjacency[u] = [(nbr, w) for nbr, w in self._adjacency[u] if nbr != v]
        self._adjacency[v] = [(nbr, w) for nbr, w in self._adjacency[v] if nbr != u]

        self.edges.append((u, v, float(weight)))
        self._adjacency[u].append((v, float(weight)))
        self._adjacency[v].append((u, float(weight)))

    def get_neighbors(self, node: int) -> List[Tuple[int, float]]:
        return self._adjacency.get(node, [])

    def get_edge_weight(self, u: int, v: int) -> Optional[float]:
        for nbr, w in self._adjacency.get(u, []):
            if nbr == v:
                return w
        return None

    @property
    def node_count(self) -> int:
        return len(self.nodes)

    @property
    def edge_count(self) -> int:
        return len(self.edges)

    @property
    def density(self) -> float:
        n = self.node_count
        if n < 2:
            return 0.0
        max_edges = n * (n - 1) / 2
        return round(self.edge_count / max_edges, 2)

    @property
    def fingerprint(self) -> str:
        """
        Deterministic canonical fingerprint of graph topology and edge weights.
        Invariant to edge insertion order or internal dictionary order.
        """
        canonical_nodes = sorted(list(self.nodes))
        canonical_edges = sorted(
            (min(u, v), max(u, v), round(float(w), 6))
            for u, v, w in self.edges
        )
        data_str = f"NODES:{canonical_nodes}|EDGES:{canonical_edges}"
        return hashlib.sha256(data_str.encode("utf-8")).hexdigest()[:12]

    def validate_path(self, path: List[int], source: int, target: int) -> Tuple[bool, float, str]:
        """
        Validates that a path is a valid sequence of connected nodes from source to target,
        and computes the actual total edge weight.
        Returns: (is_valid, actual_distance, error_message)
        """
        if not path:
            return False, float("inf"), "Empty path"
        if path[0] != source:
            return False, float("inf"), f"Path starts at {path[0]} instead of source {source}"
        if path[-1] != target:
            return False, float("inf"), f"Path ends at {path[-1]} instead of target {target}"
        if len(path) == 1:
            if source == target:
                return True, 0.0, ""
            return False, float("inf"), f"Single-node path {path} does not connect {source} to {target}"

        total_weight = 0.0
        for i in range(len(path) - 1):
            u, v = path[i], path[i + 1]
            w = self.get_edge_weight(u, v)
            if w is None:
                return False, float("inf"), f"No edge between {u} and {v}"
            total_weight += w

        return True, round(total_weight, 6), ""

    def actual_path_distance(self, path: List[int]) -> float:
        """Computes the total edge weight sum along a path, or infinity if invalid."""
        if not path:
            return float("inf")
        if len(path) == 1:
            return 0.0
        total = 0.0
        for i in range(len(path) - 1):
            w = self.get_edge_weight(path[i], path[i + 1])
            if w is None:
                return float("inf")
            total += w
        return round(total, 6)

    def is_connected(self) -> bool:
        if not self.nodes:
            return True
        start_node = next(iter(self.nodes))
        visited: Set[int] = set()
        queue = [start_node]
        visited.add(start_node)

        while queue:
            curr = queue.pop(0)
            for nbr, _ in self.get_neighbors(curr):
                if nbr not in visited:
                    visited.add(nbr)
                    queue.append(nbr)

        return len(visited) == len(self.nodes)

    def clone(self) -> "GraphData":
        new_graph = GraphData(is_synthetic=self.is_synthetic)
        new_graph.name = self.name
        new_graph.version = self.version
        for node in self.nodes:
            new_graph.add_node(node, self.positions.get(node))
        for u, v, w in self.edges:
            new_graph.add_edge(u, v, w)
        return new_graph
