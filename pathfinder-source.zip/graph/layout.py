"""
Graph layout algorithms and coordinate positioning.
"""

from typing import Dict, Tuple
import networkx as nx
from .graph_data import GraphData


def compute_spring_layout(
    graph: GraphData,
    width: float = 760.0,
    height: float = 420.0,
    padding: float = 70.0,
    seed: int = 42
) -> Dict[int, Tuple[float, float]]:
    """
    Computes a clean, aesthetically spaced spring layout for the graph.
    """
    if graph.node_count == 0:
        return {}

    G = nx.Graph()
    for node in graph.nodes:
        G.add_node(node)
    for u, v, w in graph.edges:
        G.add_edge(u, v, weight=w)

    # Use networkx spring layout with optimal distance k
    k = 1.6 / (graph.node_count ** 0.5) if graph.node_count > 0 else 1.0
    pos_raw = nx.spring_layout(G, k=k, iterations=60, seed=seed)

    # Normalize to [padding, width - padding] and [padding, height - padding]
    xs = [p[0] for p in pos_raw.values()]
    ys = [p[1] for p in pos_raw.values()]

    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)

    range_x = (max_x - min_x) if (max_x - min_x) > 1e-5 else 1.0
    range_y = (max_y - min_y) if (max_y - min_y) > 1e-5 else 1.0

    usable_w = width - 2 * padding
    usable_h = height - 2 * padding

    result_positions: Dict[int, Tuple[float, float]] = {}
    for node, (raw_x, raw_y) in pos_raw.items():
        norm_x = padding + ((raw_x - min_x) / range_x) * usable_w
        norm_y = padding + ((raw_y - min_y) / range_y) * usable_h
        result_positions[node] = (round(norm_x, 1), round(norm_y, 1))

    return result_positions
