"""
Graph generator creating reference graphs and random synthetic connected graphs.
"""

import random
from typing import Optional
from .graph_data import GraphData
from .layout import compute_spring_layout


def create_reference_8node_graph() -> GraphData:
    """
    Creates the exact 8-node reference graph featured in the PathFinder Lab design.
    Shortest path 1 -> 3 -> 5 -> 7 -> 8 has length 8.
    Nodes: 8, Edges: 12, Density: 0.43.
    """
    g = GraphData(is_synthetic=True)
    g.name = "Reference 8-Node Graph (Synthetic)"

    # Coordinates calibrated to match reference visual layout
    positions = {
        1: (100.0, 220.0),
        2: (260.0, 110.0),
        3: (240.0, 310.0),
        4: (430.0, 95.0),
        5: (420.0, 230.0),
        6: (550.0, 360.0),
        7: (620.0, 200.0),
        8: (750.0, 250.0),
    }

    for node_id, pos in positions.items():
        g.add_node(node_id, pos)

    # 12 edges with exact reference weights
    edges = [
        (1, 2, 4.0),
        (1, 3, 3.0),
        (2, 4, 2.0),
        (2, 5, 5.0),
        (3, 5, 1.0),
        (3, 6, 7.0),
        (4, 5, 3.0),
        (4, 7, 2.0),
        (5, 7, 2.0),
        (5, 6, 6.0),
        (6, 7, 3.0),
        (7, 8, 2.0),
    ]

    for u, v, w in edges:
        g.add_edge(u, v, w)

    return g


def generate_connected_graph(
    num_nodes: int = 8,
    seed: Optional[int] = None
) -> GraphData:
    """
    Generates a connected undirected graph with positive weights and sensible density.
    """
    num_nodes = max(2, min(100, num_nodes))

    rng = random.Random(seed)
    g = GraphData(is_synthetic=True)
    g.name = f"Synthetic Connected Graph (N={num_nodes})"

    for i in range(1, num_nodes + 1):
        g.add_node(i)

    # Step 1: Create a random spanning tree using Wilson's or random tree attachment
    # to guarantee 100% connectivity.
    nodes_list = list(range(1, num_nodes + 1))
    connected = [nodes_list[0]]
    unconnected = nodes_list[1:]
    rng.shuffle(unconnected)

    while unconnected:
        u = unconnected.pop()
        v = rng.choice(connected)
        weight = float(rng.randint(1, 9))
        g.add_edge(u, v, weight)
        connected.append(u)

    # Step 2: Add additional edges based on target density
    # For small graphs, aim for density ~0.35 - 0.45; for large graphs, ~0.10 - 0.20
    max_possible_edges = num_nodes * (num_nodes - 1) // 2
    if num_nodes <= 10:
        target_edges = min(max_possible_edges, max(num_nodes, int(max_possible_edges * 0.42)))
    elif num_nodes <= 25:
        target_edges = min(max_possible_edges, int(num_nodes * 2.2))
    else:
        target_edges = min(max_possible_edges, int(num_nodes * 1.8))

    all_pairs = []
    existing_edges = set((min(u, v), max(u, v)) for u, v, _ in g.edges)
    for i in range(1, num_nodes + 1):
        for j in range(i + 1, num_nodes + 1):
            if (i, j) not in existing_edges:
                all_pairs.append((i, j))

    rng.shuffle(all_pairs)
    edges_to_add = max(0, target_edges - g.edge_count)
    for i in range(min(edges_to_add, len(all_pairs))):
        u, v = all_pairs[i]
        weight = float(rng.randint(1, 10))
        g.add_edge(u, v, weight)

    # Step 3: Compute clean 2D positions
    positions = compute_spring_layout(g, seed=seed if seed is not None else 42)
    for node, pos in positions.items():
        g.positions[node] = pos

    return g
