"""
Dijkstra's Shortest Path Algorithm implementation.
Adjacency list with binary min-heap priority queue.
Time Complexity: O((V + E) log V)
Space Complexity: O(V)
"""

import heapq
from typing import List, Tuple, Dict, Optional, Set
from .base import AlgorithmResult, StepTrace


def dijkstra_shortest_path(
    graph,
    source: int,
    target: int,
    record_steps: bool = False
) -> AlgorithmResult:
    """
    Executes Dijkstra's algorithm to find the shortest path from source to target.
    
    Args:
        graph: GraphData object providing get_nodes(), get_neighbors(node)
        source: Source node ID
        target: Target node ID
        record_steps: If True, captures full step-by-step trace for UI playback
        
    Returns:
        AlgorithmResult containing path, distance, metrics, and trace
    """
    result = AlgorithmResult(
        algorithm_name="Dijkstra's Algorithm",
        source=source,
        target=target,
        theoretical_time="O((V + E) log V)",
        theoretical_space="O(V)"
    )

    if source not in graph.nodes or target not in graph.nodes:
        result.status = "Error: Invalid source or target"
        return result

    if source == target:
        result.path = [source]
        result.total_distance = 0.0
        result.nodes_visited = 1
        result.status = "Completed"
        if record_steps:
            result.steps.append(StepTrace(
                step_index=1,
                description=f"Source and target are identical ({source}). Path distance is 0.",
                current_node=source,
                visited_nodes=[source],
                current_distances={source: 0.0},
                current_path=[source]
            ))
        return result

    distances: Dict[int, float] = {node: float("inf") for node in graph.nodes}
    predecessors: Dict[int, Optional[int]] = {node: None for node in graph.nodes}
    visited: Set[int] = set()
    explored_edges: List[Tuple[int, int]] = []
    relaxed_edges: List[Tuple[int, int]] = []

    distances[source] = 0.0
    pq: List[Tuple[float, int]] = [(0.0, source)]

    nodes_visited_count = 0
    edges_examined_count = 0
    step_counter = 0

    if record_steps:
        step_counter += 1
        result.steps.append(StepTrace(
            step_index=step_counter,
            description=f"Initialized distances. Starting search from source node {source} with distance 0.",
            current_node=source,
            visited_nodes=list(visited),
            current_distances=dict(distances),
            current_path=[source]
        ))

    while pq:
        current_dist, u = heapq.heappop(pq)

        if u in visited:
            continue

        visited.add(u)
        nodes_visited_count += 1

        # Reconstruct path so far for visualization
        def reconstruct_current(curr: int) -> List[int]:
            p = []
            curr_p = curr
            while curr_p is not None:
                p.append(curr_p)
                curr_p = predecessors[curr_p]
            p.reverse()
            return p

        if record_steps:
            step_counter += 1
            result.steps.append(StepTrace(
                step_index=step_counter,
                description=f"Visited node {u} (minimum unvisited distance: {current_dist:.2f}).",
                current_node=u,
                visited_nodes=list(visited),
                current_distances=dict(distances),
                relaxed_edges=list(relaxed_edges),
                current_path=reconstruct_current(u)
            ))

        if u == target:
            # Reached target with optimal shortest path
            break

        for v, weight in graph.get_neighbors(u):
            edges_examined_count += 1
            explored_edges.append((u, v))

            new_dist = current_dist + weight
            if new_dist < distances[v]:
                distances[v] = new_dist
                predecessors[v] = u
                heapq.heappush(pq, (new_dist, v))
                relaxed_edges.append((u, v))

                if record_steps:
                    step_counter += 1
                    result.steps.append(StepTrace(
                        step_index=step_counter,
                        description=f"Relaxed edge ({u} → {v}, weight {weight:.1f}): Updated distance of node {v} to {new_dist:.2f}.",
                        current_node=u,
                        visited_nodes=list(visited),
                        current_distances=dict(distances),
                        relaxed_edges=list(relaxed_edges),
                        active_edge=(u, v),
                        current_path=reconstruct_current(v)
                    ))

    # Reconstruct final shortest path
    if distances[target] < float("inf"):
        path = []
        curr = target
        while curr is not None:
            path.append(curr)
            curr = predecessors[curr]
        path.reverse()

        if path and path[0] == source and path[-1] == target:
            actual_dist = 0.0
            valid_path = True
            for idx in range(len(path) - 1):
                w = graph.get_edge_weight(path[idx], path[idx + 1])
                if w is None:
                    valid_path = False
                    break
                actual_dist += w

            if valid_path:
                result.path = path
                result.total_distance = round(actual_dist, 6)
                result.status = "Completed"
            else:
                result.path = []
                result.total_distance = float("inf")
                result.status = "No Path"
        else:
            result.path = []
            result.total_distance = float("inf")
            result.status = "No Path"
    else:
        result.path = []
        result.total_distance = float("inf")
        result.status = "No Path"

    result.nodes_visited = nodes_visited_count
    result.edges_examined = edges_examined_count
    result.explored_edges = explored_edges

    if record_steps:
        step_counter += 1
        if result.has_path:
            desc = f"Search completed! Optimal path found: {result.path_string} with total distance {result.total_distance:.2f}."
        else:
            desc = f"Search completed! Target node {target} is unreachable from source node {source}."
        result.steps.append(StepTrace(
            step_index=step_counter,
            description=desc,
            current_node=target if result.has_path else None,
            visited_nodes=list(visited),
            current_distances=dict(distances),
            relaxed_edges=list(relaxed_edges),
            current_path=result.path
        ))

    return result
