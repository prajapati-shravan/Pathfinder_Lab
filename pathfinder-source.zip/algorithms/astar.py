"""
A* (A-Star) Shortest Path Algorithm implementation.
Priority queue with g-score, f-score, and provably admissible heuristic.
Time Complexity: O((V + E) log V) with consistent heuristic
Space Complexity: O(V)
"""

import math
import heapq
from typing import List, Tuple, Dict, Optional, Set
from .base import AlgorithmResult, StepTrace


def calculate_admissible_heuristic_factor(graph) -> float:
    """
    Computes a guaranteed admissible scale factor for Euclidean distance heuristic.
    For admissibility: h(u, target) <= true_shortest_distance(u, target).
    By Lipschitz condition, if h(u, v) <= weight(u, v) for all edges (u, v),
    then h is consistent and admissible.
    Returns 0.0 (safe h=0) if any node lacks positions or if no safe scale exists.
    """
    if not hasattr(graph, "positions") or not graph.positions or not graph.edges:
        return 0.0

    # Every node in the graph must have valid 2D coordinates
    for node in graph.nodes:
        if node not in graph.positions or graph.positions[node] is None:
            return 0.0

    min_ratio = float("inf")
    for u, v, weight in graph.edges:
        if weight <= 0:
            return 0.0
        if u in graph.positions and v in graph.positions:
            x1, y1 = graph.positions[u]
            x2, y2 = graph.positions[v]
            euclid_d = math.hypot(x2 - x1, y2 - y1)
            if euclid_d <= 1e-6:
                # Two connected nodes share identical positions with positive edge weight
                return 0.0
            ratio = weight / euclid_d
            if ratio < min_ratio:
                min_ratio = ratio
        else:
            return 0.0

    if min_ratio == float("inf") or min_ratio <= 0:
        return 0.0

    # 0.999 factor provides safety margin against floating point rounding
    return 0.999 * min_ratio


def astar_shortest_path(
    graph,
    source: int,
    target: int,
    record_steps: bool = False,
    heuristic_type: str = "euclidean"  # "euclidean" or "zero"
) -> AlgorithmResult:
    """
    Executes A* algorithm to find shortest path from source to target.
    
    Args:
        graph: GraphData object
        source: Source node ID
        target: Target node ID
        record_steps: If True, captures step-by-step trace for playback
        heuristic_type: "euclidean" (calibrated admissible) or "zero"
        
    Returns:
        AlgorithmResult containing path, distance, metrics, and trace
    """
    result = AlgorithmResult(
        algorithm_name="A* Algorithm",
        source=source,
        target=target,
        theoretical_time="O((V + E) log V)",
        theoretical_space="O(V)"
    )

    if source not in graph.nodes or target not in graph.nodes:
        result.status = "Error: Invalid source or target"
        return result

    if source == target:
        result.path = [source]
        result.total_distance = 0.0
        result.nodes_visited = 1
        result.status = "Completed"
        if record_steps:
            result.steps.append(StepTrace(
                step_index=1,
                description=f"Source and target are identical ({source}). Path distance is 0.",
                current_node=source,
                visited_nodes=[source],
                current_distances={source: 0.0},
                current_path=[source]
            ))
        return result

    # Determine heuristic scale factor
    scale_factor = 0.0
    if heuristic_type == "euclidean" and hasattr(graph, "positions") and graph.positions:
        scale_factor = calculate_admissible_heuristic_factor(graph)

    def heuristic(u: int) -> float:
        """
        Heuristic function h(u):
        Estimates the remaining straight-line distance from node u to target.
        h(target) = 0.0 (already at the destination).
        """
        if scale_factor <= 0.0 or u not in graph.positions or target not in graph.positions:
            return 0.0
        x1, y1 = graph.positions[u]
        x2, y2 = graph.positions[target]
        return scale_factor * math.hypot(x2 - x1, y2 - y1)

    # Precompute heuristic values h(n) for all nodes (easy to inspect and display)
    h_table = {node: round(heuristic(node), 2) for node in graph.nodes}

    g_scores: Dict[int, float] = {node: float("inf") for node in graph.nodes}
    f_scores: Dict[int, float] = {node: float("inf") for node in graph.nodes}
    predecessors: Dict[int, Optional[int]] = {node: None for node in graph.nodes}
    closed_set: Set[int] = set()
    explored_edges: List[Tuple[int, int]] = []
    relaxed_edges: List[Tuple[int, int]] = []

    g_scores[source] = 0.0
    f_scores[source] = h_table[source]

    # Priority queue stores (f_score, g_score, node)
    pq: List[Tuple[float, float, int]] = [(f_scores[source], 0.0, source)]

    nodes_expanded_count = 0
    edges_examined_count = 0
    step_counter = 0

    if record_steps:
        step_counter += 1
        result.steps.append(StepTrace(
            step_index=step_counter,
            description=f"Initialized A* search. Source {source} (g=0.0, h={h_table[source]:.2f}, f={f_scores[source]:.2f}).",
            current_node=source,
            visited_nodes=list(closed_set),
            current_distances=dict(g_scores),
            heuristic_values=dict(h_table),
            f_scores=dict(f_scores),
            current_path=[source]
        ))

    def reconstruct_current(curr: int) -> List[int]:
        p = []
        curr_p = curr
        while curr_p is not None:
            p.append(curr_p)
            curr_p = predecessors[curr_p]
        p.reverse()
        return p

    while pq:
        current_f, current_g, u = heapq.heappop(pq)

        if u in closed_set:
            continue

        closed_set.add(u)
        nodes_expanded_count += 1

        if record_steps:
            step_counter += 1
            h_val = h_table.get(u, heuristic(u))
            result.steps.append(StepTrace(
                step_index=step_counter,
                description=f"Expanded node {u} (g={current_g:.2f}, h={h_val:.2f}, f={current_f:.2f}).",
                current_node=u,
                visited_nodes=list(closed_set),
                current_distances=dict(g_scores),
                heuristic_values=dict(h_table),
                f_scores=dict(f_scores),
                relaxed_edges=list(relaxed_edges),
                current_path=reconstruct_current(u)
            ))

        if u == target:
            break

        for v, weight in graph.get_neighbors(u):
            edges_examined_count += 1
            explored_edges.append((u, v))

            tentative_g = current_g + weight
            if tentative_g < g_scores[v]:
                predecessors[v] = u
                g_scores[v] = tentative_g
                h_v = h_table.get(v, heuristic(v))
                new_f = tentative_g + h_v
                f_scores[v] = new_f
                # If node was previously in closed_set, allow re-expansion if reopened
                closed_set.discard(v)
                heapq.heappush(pq, (new_f, tentative_g, v))
                relaxed_edges.append((u, v))

                if record_steps:
                    step_counter += 1
                    result.steps.append(StepTrace(
                        step_index=step_counter,
                        description=f"Evaluated edge ({u} → {v}, weight {weight:.1f}): new g={tentative_g:.2f}, h={h_v:.2f}, f={new_f:.2f}.",
                        current_node=u,
                        visited_nodes=list(closed_set),
                        current_distances=dict(g_scores),
                        heuristic_values=dict(h_table),
                        f_scores=dict(f_scores),
                        relaxed_edges=list(relaxed_edges),
                        active_edge=(u, v),
                        current_path=reconstruct_current(v)
                    ))

    if g_scores[target] < float("inf"):
        path = []
        curr = target
        while curr is not None:
            path.append(curr)
            curr = predecessors[curr]
        path.reverse()

        # Validate path endpoints and calculate exact edge weight sum
        if path and path[0] == source and path[-1] == target:
            actual_dist = 0.0
            valid_path = True
            for idx in range(len(path) - 1):
                w = graph.get_edge_weight(path[idx], path[idx + 1])
                if w is None:
                    valid_path = False
                    break
                actual_dist += w

            if valid_path:
                result.path = path
                result.total_distance = round(actual_dist, 6)
                result.status = "Completed"
            else:
                result.path = []
                result.total_distance = float("inf")
                result.status = "No Path"
        else:
            result.path = []
            result.total_distance = float("inf")
            result.status = "No Path"
    else:
        result.path = []
        result.total_distance = float("inf")
        result.status = "No Path"

    result.nodes_visited = nodes_expanded_count
    result.edges_examined = edges_examined_count
    result.explored_edges = explored_edges

    if record_steps:
        step_counter += 1
        if result.has_path:
            desc = f"A* goal reached! Optimal path found: {result.path_string} with total distance {result.total_distance:.2f}."
        else:
            desc = f"Search exhausted without reaching target node {target}."
        result.steps.append(StepTrace(
            step_index=step_counter,
            description=desc,
            current_node=target if result.has_path else None,
            visited_nodes=list(closed_set),
            current_distances=dict(g_scores),
            heuristic_values=dict(h_table),
            f_scores=dict(f_scores),
            relaxed_edges=list(relaxed_edges),
            current_path=result.path
        ))

    return result
