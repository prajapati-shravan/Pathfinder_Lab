"""
Core data structures and base classes for shortest path algorithms.
"""

from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Optional, Any


@dataclass
class StepTrace:
    """Represents a single step in algorithm execution for playback."""
    step_index: int
    description: str
    current_node: Optional[int] = None
    visited_nodes: List[int] = field(default_factory=list)
    current_distances: Dict[int, float] = field(default_factory=dict)
    relaxed_edges: List[Tuple[int, int]] = field(default_factory=list)
    active_edge: Optional[Tuple[int, int]] = None
    current_path: List[int] = field(default_factory=list)
    matrix_state: Optional[List[List[float]]] = None
    matrix_labels: Optional[List[int]] = None
    updated_cell: Optional[Tuple[int, int]] = None
    heuristic_values: Dict[int, float] = field(default_factory=dict)  # h(n): estimated distance to target
    f_scores: Dict[int, float] = field(default_factory=dict)          # f(n) = g(n) + h(n): total estimated cost


@dataclass
class AlgorithmResult:
    """Standardized result returned by all shortest path algorithms."""
    algorithm_name: str
    source: int
    target: int
    path: List[int] = field(default_factory=list)
    total_distance: float = float("inf")
    execution_time_ms: float = 0.0
    nodes_visited: int = 0
    edges_examined: int = 0
    matrix_updates: int = 0
    status: str = "Completed"  # "Completed", "No Path", "Error"
    explored_edges: List[Tuple[int, int]] = field(default_factory=list)
    steps: List[StepTrace] = field(default_factory=list)
    theoretical_time: str = ""
    theoretical_space: str = ""
    extra_info: Dict[str, Any] = field(default_factory=dict)

    @property
    def has_path(self) -> bool:
        return len(self.path) > 0 and self.total_distance < float("inf")

    @property
    def path_string(self) -> str:
        if not self.has_path:
            return "No Path"
        return " → ".join(str(node) for node in self.path)
