"""
Floyd-Warshall All-Pairs Shortest Path Algorithm implementation.
Dynamic programming with distance and next-hop matrices.
Time Complexity: O(V³)
Space Complexity: O(V²)
"""

from typing import List, Tuple, Dict, Optional
from .base import AlgorithmResult, StepTrace


def floyd_warshall_shortest_path(
    graph,
    source: int,
    target: int,
    record_steps: bool = False
) -> AlgorithmResult:
    """
    Executes Floyd-Warshall algorithm to compute all-pairs shortest paths,
    and extracts the shortest path from source to target.
    
    Args:
        graph: GraphData object providing get_nodes(), get_edges()
        source: Source node ID
        target: Target node ID
        record_steps: If True, captures full step-by-step trace and matrix states
        
    Returns:
        AlgorithmResult containing path, distance, metrics, matrix updates, and trace
    """
    result = AlgorithmResult(
        algorithm_name="Floyd-Warshall Algorithm",
        source=source,
        target=target,
        theoretical_time="O(V³)",
        theoretical_space="O(V²)"
    )

    nodes = sorted(list(graph.nodes))
    n = len(nodes)
    node_to_idx = {node: i for i, node in enumerate(nodes)}
    idx_to_node = {i: node for i, node in enumerate(nodes)}

    if source not in node_to_idx or target not in node_to_idx:
        result.status = "Error: Invalid source or target"
        return result

    s_idx = node_to_idx[source]
    t_idx = node_to_idx[target]

    # Initialize matrices
    dist = [[float("inf")] * n for _ in range(n)]
    next_node = [[None] * n for _ in range(n)]

    for i in range(n):
        dist[i][i] = 0.0
        next_node[i][i] = idx_to_node[i]

    # Populate direct edges
    for u, v, weight in graph.edges:
        if u in node_to_idx and v in node_to_idx:
            i, j = node_to_idx[u], node_to_idx[v]
            if weight < dist[i][j]:
                dist[i][j] = weight
                dist[j][i] = weight
                next_node[i][j] = v
                next_node[j][i] = u

    matrix_updates = 0
    total_checks = n * n * n  # V^3 iterations
    strict_updates = 0
    step_counter = 0

    if record_steps:
        step_counter += 1
        # Initial matrix snapshot
        matrix_copy = [row[:] for row in dist]
        current_distances = {node: dist[s_idx][node_to_idx[node]] for node in nodes}
        result.steps.append(StepTrace(
            step_index=step_counter,
            description="Initialized distance matrix D(0) with direct edge weights and self-loops (0).",
            current_node=source,
            current_distances=current_distances,
            matrix_state=matrix_copy,
            matrix_labels=nodes
        ))

    # Triple loop: intermediate vertex k, from i, to j
    for k in range(n):
        k_node = idx_to_node[k]
        k_updated = False

        for i in range(n):
            for j in range(n):
                matrix_updates += 1
                if dist[i][k] != float("inf") and dist[k][j] != float("inf"):
                    new_dist = dist[i][k] + dist[k][j]
                    if new_dist < dist[i][j]:
                        dist[i][j] = new_dist
                        next_node[i][j] = next_node[i][k]
                        strict_updates += 1
                        k_updated = True

        if record_steps and (k_updated or n <= 10):
            step_counter += 1
            matrix_copy = [row[:] for row in dist]
            desc = f"Completed iteration for intermediate vertex k={k_node}. Updated shortest paths using vertex {k_node}."
            current_distances = {node: dist[s_idx][node_to_idx[node]] for node in nodes}
            result.steps.append(StepTrace(
                step_index=step_counter,
                description=desc,
                current_node=k_node,
                current_distances=current_distances,
                matrix_state=matrix_copy,
                matrix_labels=nodes
            ))

    # Reconstruct path from source to target
    if dist[s_idx][t_idx] < float("inf"):
        if s_idx == t_idx:
            path = [source]
            result.path = path
            result.total_distance = 0.0
            result.status = "Completed"
        else:
            path = [source]
            curr = s_idx
            # Guard against cycles
            max_hops = n + 1
            hops = 0
            while curr != t_idx and hops < max_hops:
                next_hop_val = next_node[curr][t_idx]
                if next_hop_val is None:
                    path = []
                    break
                path.append(next_hop_val)
                curr = node_to_idx[next_hop_val]
                hops += 1

            if hops < max_hops and len(path) > 0 and path[0] == source and path[-1] == target:
                actual_d = 0.0
                valid_path = True
                for idx in range(len(path) - 1):
                    w = graph.get_edge_weight(path[idx], path[idx + 1])
                    if w is None:
                        valid_path = False
                        break
                    actual_d += w

                if valid_path:
                    result.path = path
                    result.total_distance = round(actual_d, 6)
                    result.status = "Completed"
                else:
                    result.path = []
                    result.total_distance = float("inf")
                    result.status = "No Path"
            else:
                result.path = []
                result.total_distance = float("inf")
                result.status = "No Path"
    else:
        result.path = []
        result.total_distance = float("inf")
        result.status = "No Path"

    # Floyd-Warshall examines all V nodes and all V^3 combinations
    result.nodes_visited = n
    # In reference UI: "Matrix Updates: 512" (for V=8, 8^3 = 512)
    result.matrix_updates = total_checks
    result.edges_examined = total_checks
    result.extra_info["strict_updates"] = strict_updates
    result.extra_info["total_iterations"] = total_checks
    result.extra_info["distance_matrix"] = dist
    result.extra_info["matrix_labels"] = nodes

    # Explored edges in the graph
    explored: List[Tuple[int, int]] = []
    for u, v, _ in graph.edges:
        explored.append((u, v))
    result.explored_edges = explored

    if record_steps:
        step_counter += 1
        matrix_copy = [row[:] for row in dist]
        if result.has_path:
            desc = f"All-pairs paths resolved! Extracted path for {source} → {target}: {result.path_string} (Distance: {result.total_distance:.2f})."
        else:
            desc = f"All-pairs completed. Target node {target} is unreachable from node {source}."
        current_distances = {node: dist[s_idx][node_to_idx[node]] for node in nodes}
        result.steps.append(StepTrace(
            step_index=step_counter,
            description=desc,
            current_node=target if result.has_path else None,
            current_distances=current_distances,
            current_path=result.path,
            matrix_state=matrix_copy,
            matrix_labels=nodes
        ))

    return result
